// KAR-99 P6: immutable before-click publication intent and independent outcome.
// Never infer an outcome from navigation, local session state, or client claims.
(() => {
  'use strict';
  const PREFIX='karAutoPublishIntentV1_';
  const RESOLUTION_PREFIX='karAutoPublishVerifiedResolutionV1_';
  const SHARED_LOCK_NAME='kar-updater-global-admission-v1';
  const P8_START='karAtomicAdmissionStartV1_';
  const P8_FINISH='karAtomicAdmissionFinishV1_';
  const P8_ALLOWED=new Set([
    'AUTONOMOUS:renewal-publish-detection',
    'AUTONOMOUS:trash-publish-detection',
    'AUTONOMOUS:archive-postpublish-detached',
    'AUTHORIZE_AUTOMATIC_PUBLISH'
  ]);
  const denied=code=>Object.assign(new Error(code),{code});
  const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
  const id=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(v);
  const adId=v=>typeof v==='string'&&/^\d+$/.test(v);
  const same=(a,b)=>object(a)&&object(b)&&Object.keys(a).length===Object.keys(b).length
    &&Object.keys(a).every(k=>a[k]===b[k]);
  function validIntent(key,row){
    return object(row)&&row.schema===1&&row.state==='outcome-unverified'
      &&id(row.fillId)&&id(row.workflowId)&&id(row.attemptId)&&id(row.workerInstanceId)
      &&['renewal','archive'].includes(row.kind)
      &&typeof row.profileId==='string'&&Boolean(row.profileId.trim())&&row.profileId.length<=256
      &&Number.isSafeInteger(row.targetTabId)&&row.targetTabId>0
      &&(adId(row.sourceAdId)||(row.kind==='archive'&&row.sourceAdId===''))
      &&Number.isSafeInteger(row.createdAtMs)&&row.createdAtMs>=0
      &&(row.admissionToken===undefined||
        (id(row.admissionToken)&&row.admissionToken.length>=12))
      &&key===PREFIX+row.fillId+'_'+row.attemptId;
  }
  // Historical roster proofs retain their exact cardinality contract.
  // The direct route is Renewal-only and requires BOTH independently
  // observed IDs; it cannot carry manufactured roster page counters.
  function validTargetEvidence(row){
    if(row.targetEvidence==='found-in-my-ads-full-pagination-scan')
      return Number.isSafeInteger(row.targetPagesScanned)&&row.targetPagesScanned>=1
        &&Number.isSafeInteger(row.targetFoundPage)&&row.targetFoundPage>=1
        &&row.targetFoundPage<=row.targetPagesScanned
        &&!Object.hasOwn(row,'targetEditAdId')&&!Object.hasOwn(row,'targetPublicAdId');
    return row.kind==='renewal'&&row.targetEvidence==='verified-edit-and-public-listing'
      &&adId(row.newAdId)&&row.targetEditAdId===row.newAdId&&row.targetPublicAdId===row.newAdId
      &&!Object.hasOwn(row,'targetPagesScanned')&&!Object.hasOwn(row,'targetFoundPage');
  }
  function validResolution(key,row,intent){
    return object(row)&&validIntent(PREFIX+intent?.fillId+'_'+intent?.attemptId,intent)
      &&row.schema===1&&row.state==='resolved-confirmed'
      &&row.fillId===intent.fillId&&row.workflowId===intent.workflowId
      &&row.attemptId===intent.attemptId&&row.kind===intent.kind
      &&row.profileId===intent.profileId&&row.sourceAdId===intent.sourceAdId
      &&row.targetTabId===intent.targetTabId&&adId(row.newAdId)
      &&row.newAdId!==intent.sourceAdId&&row.targetPresent===true
      &&validTargetEvidence(row)
      &&Number.isSafeInteger(row.verifiedAtMs)&&row.verifiedAtMs>=intent.createdAtMs
      &&key===RESOLUTION_PREFIX+row.fillId+'_'+row.attemptId;
  }
  function create({storageLocal,lockManager,lockName,workerInstanceId,clock,newToken,
    verifyRemoteOutcome=null,onSample=null,onResolutionDenied=null,verifyCommitContext=null,
    prepareCommitContext=null,requireCommitContext=false,beginLockWaitMs=0,resolveLockWaitMs=0}={}){
    if(typeof storageLocal?.get!=='function'||typeof storageLocal?.set!=='function'
       ||typeof clock!=='function'||typeof newToken!=='function'||!id(workerInstanceId))
      throw denied('KR_PUBLISH_INTENT_STORAGE');
    if([beginLockWaitMs,resolveLockWaitMs].some(ms=>!Number.isSafeInteger(ms)||ms<0||ms>60000))
      throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
    // Observability only: a fixed stage, never a profile, listing ID, attempt
    // token or authorization result. A telemetry failure cannot alter safety.
    function noteResolutionDenied(stage){
      if(typeof onResolutionDenied==='function') {
        try { onResolutionDenied(Object.freeze({stage})); } catch { /* telemetry is inert */ }
      }
    }
    async function read(keys){
      try{const v=await storageLocal.get(keys);if(!object(v))throw Error('invalid read');return v;}
      catch{throw denied('KR_PUBLISH_INTENT_STORAGE');}
    }
    function snapshot(rows,fillId){
      const attempts=new Map(),resolutions=new Map();
      for(const [key,row] of Object.entries(rows)){
        if(key.startsWith(PREFIX)){
          if(!validIntent(key,row))throw denied('KR_PUBLISH_INTENT_CORRUPT');
          attempts.set(key.slice(PREFIX.length),row);
        }else if(key.startsWith(RESOLUTION_PREFIX)){
          resolutions.set(key.slice(RESOLUTION_PREFIX.length),row);
        }
      }
      for(const [suffix,row] of resolutions){
        if(!validResolution(RESOLUTION_PREFIX+suffix,row,attempts.get(suffix)))
          throw denied('KR_PUBLISH_INTENT_CORRUPT');
      }
      const matching=[...attempts.values()].filter(v=>v.fillId===fillId);
      const resolved=[...resolutions.values()].filter(v=>v.fillId===fillId);
      if(matching.length>1||resolved.length>1)
        throw denied('KR_PUBLISH_INTENT_CORRUPT');
      return Object.freeze({
        state:matching.length?(resolved.length?'resolved':'unverified'):'missing',
        attempts:Object.freeze(matching.map(v=>Object.freeze({...v}))),
        resolutions:Object.freeze(resolved.map(v=>Object.freeze({...v})))
      });
    }
    async function observe(fillId){
      if(!id(fillId))throw denied('KR_PUBLISH_INTENT_IDENTITY');
      return snapshot(await read(null),fillId);
    }
    // KAR-197: P8 and publication-intent receipts share the exact origin Web Lock.
    // Retry ONLY a denial that occurred before entering any critical section.
    // Each acquired attempt independently scans the complete immutable journal;
    // an existing before-click receipt can never be replayed or overwritten.
    async function atomic(task,phase='begin'){
      if(typeof lockManager?.request!=='function'||lockName!==SHARED_LOCK_NAME)
        throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
      const beganAt=Date.now();
      let busyAttempts=0,holdMs=0,outcome='denied';
      try{
        // Production queues both before-click and resolution acquisitions.
        // Abort only the pending request; an entered critical section must
        // finish its durable write/readback under the same exclusive lock.
        const waitMs=phase==='begin'?beginLockWaitMs:resolveLockWaitMs;
        if(waitMs>0){
          if(typeof AbortController!=='function')throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
          const controller=new AbortController();
          let entered=false,finished=false;
          const deadline=setTimeout(()=>controller.abort(),waitMs);
          try{
            const value=await lockManager.request(SHARED_LOCK_NAME,
              {mode:'exclusive',signal:controller.signal},async lock=>{
                if(controller.signal.aborted)throw denied('KR_PUBLISH_INTENT_ATOMIC_BUSY');
                if(entered||!lock||lock.name!==SHARED_LOCK_NAME||lock.mode!=='exclusive')
                  throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
                entered=true;
                clearTimeout(deadline);
                const heldAt=Date.now();
                try{const result=await task();finished=true;return result;}
                finally{holdMs=Math.min(60000,Math.max(0,Date.now()-heldAt));}
              });
            if(!entered||!finished)throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
            outcome='ok';return value;
          }catch(error){
            if(!entered&&controller.signal.aborted){busyAttempts=1;throw denied('KR_PUBLISH_INTENT_ATOMIC_BUSY');}
            if(typeof error?.code==='string'&&error.code.startsWith('KR_PUBLISH_INTENT_'))throw error;
            throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
          }finally{clearTimeout(deadline);}
        }
        const attempts=16;
        for(let i=0;i<attempts;i++){
          let entered=false,finished=false,preLockBusy=false;
          try{
            const value=await lockManager.request(SHARED_LOCK_NAME,
              {mode:'exclusive',ifAvailable:true},async lock=>{
                if(entered)throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
                entered=true;
                if(!lock){
                  preLockBusy=true;
                  throw denied('KR_PUBLISH_INTENT_ATOMIC_BUSY');
                }
                if(lock.name!==SHARED_LOCK_NAME||lock.mode!=='exclusive')
                  throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
                const heldAt=Date.now();
                try{
                  const result=await task();
                  finished=true;
                  return result;
                }finally{holdMs=Math.min(60000,Math.max(0,Date.now()-heldAt));}
              });
            // A broken lock implementation must not resolve before the
            // awaited journal write/readback and validated callback finish.
            if(!entered||!finished)throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
            outcome='ok';
            return value;
          }catch(error){
            if(preLockBusy&&error?.code==='KR_PUBLISH_INTENT_ATOMIC_BUSY'){
              busyAttempts++;
              if(i<attempts-1){
                await new Promise(resolve=>setTimeout(resolve,Math.min(20+i*10,100)));
                continue;
              }
            }
            if(typeof error?.code==='string'&&error.code.startsWith('KR_PUBLISH_INTENT_'))
              throw error;
            throw denied('KR_PUBLISH_INTENT_ATOMIC_UNAVAILABLE');
          }
        }
        throw denied('KR_PUBLISH_INTENT_ATOMIC_BUSY');
      }finally{
        // Only fixed phase, bounded timings and attempts: no fill/account/token
        // identifiers. A telemetry hook cannot affect publish authorization.
        if(typeof onSample==='function'){
          try{onSample(Object.freeze({
            phase,busyAttempts,
            waitMs:Math.min(60000,Math.max(0,Date.now()-beganAt-holdMs)),
            holdMs,outcome
          }));}catch{}
        }
      }
    }
    async function durable(key,entry){
      try{await storageLocal.set({[key]:entry});}
      catch{throw denied('KR_PUBLISH_INTENT_STORAGE');}
      if(!same((await read([key]))[key],entry))throw denied('KR_PUBLISH_INTENT_STORAGE');
    }
    async function verifiedAdmissionToken(reference,createdAtMs){
      if(!object(reference)||!Object.isFrozen(reference)
         ||reference.schema!==1||reference.state!=='admitted'
         ||!id(reference.token)||reference.token.length<12
         ||reference.workerInstanceId!==workerInstanceId
         ||!P8_ALLOWED.has(reference.operationType)
         ||!Number.isSafeInteger(reference.startedAtMs)
         ||reference.startedAtMs<0||reference.startedAtMs>createdAtMs)
        throw denied('KR_PUBLISH_INTENT_ADMISSION_UNVERIFIED');
      // Same origin lock as P8 start/finish; no user-supplied or stale
      // token can substitute for a storage-acknowledged live admission.
      const rows=await read([P8_START+reference.token,P8_FINISH+reference.token]);
      if(!same(rows[P8_START+reference.token],reference)
        ||rows[P8_FINISH+reference.token]!==undefined)
        throw denied('KR_PUBLISH_INTENT_ADMISSION_UNVERIFIED');
      return reference.token;
    }
    async function begin({fillId,workflowId,kind,profileId,sourceAdId,targetTabId,
      admissionReceipt=null}={}){
      if(!id(fillId)||!id(workflowId)||!['renewal','archive'].includes(kind)
         ||typeof profileId!=='string'||!profileId.trim()||profileId.length>256
         ||!Number.isSafeInteger(targetTabId)||targetTabId<=0
         ||!(adId(sourceAdId)||(kind==='archive'&&sourceAdId==='')))
        throw denied('KR_PUBLISH_INTENT_IDENTITY');
      return atomic(async()=>{
        const rows=await read(null);
        if(snapshot(rows,fillId).attempts.length)throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        let attemptId;
        try{attemptId=newToken();}catch{throw denied('KR_PUBLISH_INTENT_IDENTITY');}
        const createdAtMs=clock();
        if(!id(attemptId)||!Number.isSafeInteger(createdAtMs)||createdAtMs<0)
          throw denied('KR_PUBLISH_INTENT_IDENTITY');
        const key=PREFIX+fillId+'_'+attemptId;
        if(Object.hasOwn(rows,key))throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        const admissionToken=admissionReceipt===null?null
          :await verifiedAdmissionToken(admissionReceipt,createdAtMs);
        const entry=Object.freeze({schema:1,state:'outcome-unverified',fillId,workflowId,
          kind,profileId,sourceAdId,targetTabId,attemptId,workerInstanceId,createdAtMs,
          ...(admissionToken?{admissionToken}:{})});
        await durable(key,entry);
        const after=await observe(fillId);
        if(after.attempts.length!==1||!same(after.attempts[0],entry))
          throw denied('KR_PUBLISH_INTENT_STORAGE');
        return entry;
      },'begin');
    }
    // R1: An original P8-bound publication intent may be reverified by a
    // restarted Worker, but it must still identify the SAME durable origin.
    // Acquire the existing origin Web Lock for each P8 source read, never
    // throughout a network scan. Tokenless legacy records stay historical
    // and do not themselves confer all-owner/update authority.
    async function originalP8Signature(intent){
      if(!Object.hasOwn(intent,'admissionToken'))return null;
      const token=intent.admissionToken;
      const rows=await read([P8_START+token,P8_FINISH+token]);
      const start=rows[P8_START+token],finish=rows[P8_FINISH+token];
      if(!object(start)||Object.keys(start).length!==6
         ||start.schema!==1||start.state!=='admitted'
         ||start.token!==token||!P8_ALLOWED.has(start.operationType)
         ||start.workerInstanceId!==intent.workerInstanceId
         ||!Number.isSafeInteger(start.startedAtMs)||start.startedAtMs<0
         ||start.startedAtMs>intent.createdAtMs)
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      if(finish!==undefined&&(!object(finish)||Object.keys(finish).length!==5
         ||finish.schema!==1||finish.state!=='completed'
         ||finish.token!==token||finish.workerInstanceId!==start.workerInstanceId
         ||!Number.isSafeInteger(finish.completedAtMs)
         ||finish.completedAtMs<intent.createdAtMs))
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      return JSON.stringify([start,finish??null]);
    }
    async function resolveVerified({fillId,newAdId}={}){
      if(!id(fillId)||!adId(newAdId))throw denied('KR_PUBLISH_INTENT_IDENTITY');
      if(requireCommitContext&&(typeof verifyCommitContext!=='function'||
          typeof prepareCommitContext!=='function'))
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      let originSignature;
      const intent=await atomic(async()=>{
        const state=await observe(fillId);
        if(state.attempts.length!==1)throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        if(state.attempts[0].sourceAdId===newAdId)throw denied('KR_PUBLISH_INTENT_IDENTITY');
        if(state.resolutions.length&&state.resolutions[0].newAdId!==newAdId)
          throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        originSignature=await originalP8Signature(state.attempts[0]);
        return state.attempts[0];
      },'resolve-read');
      if(typeof verifyRemoteOutcome!=='function')throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      let proof;
      try{proof=await verifyRemoteOutcome(Object.freeze({...intent}),newAdId);}
      catch{
        noteResolutionDenied('remote-outcome-unavailable');
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      }
      if(!object(proof)||proof.fillId!==intent.fillId||proof.workflowId!==intent.workflowId
        ||proof.kind!==intent.kind||proof.profileId!==intent.profileId
        ||proof.sourceAdId!==intent.sourceAdId||proof.newAdId!==newAdId
        ||proof.targetPresent!==true||!validTargetEvidence(proof)) {
        noteResolutionDenied('remote-outcome-unverified');
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      }
      // A fresh publication presence result can only confirm the exact
      // originating P8 attempt (not another attempt with the same Ad IDs).
      if(Object.hasOwn(intent,'admissionToken') &&
         (proof.attemptId!==intent.attemptId||
          proof.workerInstanceId!==intent.workerInstanceId||
          proof.admissionToken!==intent.admissionToken)) {
        noteResolutionDenied('remote-outcome-unverified');
        throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
      }
      // A separately owned account tab is staged before entering the lock.
      let witness=null;
      if(requireCommitContext){
        try{witness=await prepareCommitContext(Object.freeze({...intent}));}
        catch{
          noteResolutionDenied('account-witness-unavailable');
          throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
        }
        if(!witness||!Number.isSafeInteger(witness.tabId)||witness.tabId<=0||
            typeof witness.close!=='function') {
          noteResolutionDenied('account-witness-unavailable');
          throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
        }
      }
      try{return await atomic(async()=>{
        const after=await observe(fillId);
        if(after.attempts.length!==1||!same(after.attempts[0],intent))
          throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        if(await originalP8Signature(intent)!==originSignature)
          throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
        // Real production asks a private trusted, READ-ONLY account/session
        // witness again with this exact origin Web Lock held, just before
        // committing a positive result. No network navigation under this lock.
        if(requireCommitContext){
          let accepted=false;
          try{accepted=await verifyCommitContext(Object.freeze({...intent}),witness);}
          catch{/* No positive evidence from an unavailable source. */}
          if(accepted!==true){
            noteResolutionDenied('account-witness-unverified');
            throw denied('KR_PUBLISH_INTENT_UNVERIFIED');
          }
        }
        if(after.resolutions.length){
          if(after.resolutions[0].newAdId!==newAdId)
            throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
          return after.resolutions[0]; // independently reverified, immutable.
        }
        const verifiedAtMs=clock();
        if(!Number.isSafeInteger(verifiedAtMs)||verifiedAtMs<intent.createdAtMs)
          throw denied('KR_PUBLISH_INTENT_IDENTITY');
        const result=Object.freeze({schema:1,state:'resolved-confirmed',
          fillId:intent.fillId,workflowId:intent.workflowId,kind:intent.kind,
          profileId:intent.profileId,sourceAdId:intent.sourceAdId,
          targetTabId:intent.targetTabId,attemptId:intent.attemptId,newAdId,
          targetPresent:true,targetEvidence:proof.targetEvidence,
          ...(proof.targetEvidence==='verified-edit-and-public-listing'
            ?{targetEditAdId:proof.targetEditAdId,targetPublicAdId:proof.targetPublicAdId}
            :{targetPagesScanned:proof.targetPagesScanned,targetFoundPage:proof.targetFoundPage}),
          verifiedAtMs});
        const key=RESOLUTION_PREFIX+intent.fillId+'_'+intent.attemptId;
        if((await read([key]))[key]!==undefined)
          throw denied('KR_PUBLISH_INTENT_UNRESOLVED');
        await durable(key,result);
        if(!validResolution(key,result,intent)
          ||!same((await observe(fillId)).resolutions[0],result))
          throw denied('KR_PUBLISH_INTENT_STORAGE');
        return result;
      },'resolve-write');}finally{
        if(witness)await Promise.resolve().then(()=>witness.close()).catch(()=>{});
      }
    }
    return Object.freeze({begin,observe,resolveVerified});
  }
  const API=Object.freeze({create,KEY_PREFIX:PREFIX,RESOLUTION_KEY_PREFIX:RESOLUTION_PREFIX});
  globalThis.KRDeps?.register?.('KRAutoPublishIntentJournal',API);
  if(typeof module!=='undefined'&&module?.exports)module.exports=API;
})();
