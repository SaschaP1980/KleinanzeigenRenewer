importScripts("../shared/runtime-deps.js", "../shared/message-contract-registry.js", "../shared/renewal-policy.js", "background-message-router.js", "services/native-update-status-gateway.js", "services/native-status-bridge.js", "services/update-workflow-fence.js", "repositories/profile-repository.js", "repositories/inventory-repository.js", "repositories/inventory-image-store.js", "services/inventory-capture-service.js", "services/inventory-refresh-service.js", "services/trash-service.js", "controllers/trash-management-controller.js", "services/diagnostics-service.js", "services/diagnostic-correlation-service.js", "services/listing-url-evidence-service.js", "services/tab-registry.js", "services/managed-tab-worker-service.js", "services/content-connection-manager.js", "services/account-probe-service.js", "controllers/profile-management-controller.js", "controllers/account-session-controller.js", "controllers/manual-listing-navigation-controller.js", "controllers/platform-safety-controller.js", "controllers/tab-lifecycle-observer.js", "controllers/workflow-emergency-reset-controller.js", "lib/bulk-run-guard.js", "controllers/single-inventory-controller.js", "services/bulk-worker-service.js", "services/bulk-reconciliation-service.js", "controllers/bulk-inventory-controller.js", "controllers/mass-renewal-controller.js", "services/mass-renewal-watchdog-service.js", "controllers/mass-renewal-workflow-controller.js", "services/renewal-verification-flow.js", "services/renewal-reinventory-flow.js", "services/renewal-phase1-retry-service.js", "services/paid-checkout-recovery-service.js", "controllers/renewal-workflow-controller.js", "services/renewal-verification-service.js", "repositories/renewal-state-repository.js", "services/template-fill-service.js", "services/insertion-lock-service.js", "controllers/template-fill-controller.js", "services/trash-template-publish-detection-service.js", "services/archive-insertion-service.js", "services/archive-insertion-verification-service.js", "services/archive-insertion-recovery-service.js", "controllers/archive-insertion-controller.js", "services/remote-delete-replacement-service.js", "services/published-inventory-resolver.js", "services/diagnostic-export-service.js", "services/public-listing-evidence-service.js", "services/renewal-public-evidence-coordinator.js", "../shared/managed-navigation.js", "lib/inventory-reconciliation.js", "../shared/my-ads-readiness.js", "lib/inventory-scope.js", "../shared/platform-hardening.js", "services/tab-load-coordinator.js", "../shared/template-schema-core.js", "services/persisted-owner-observer.js", "services/additional-owner-observer.js", "services/phase4-uncertainty-journal.js", "services/cross-worker-atomic-admission.js", "services/auto-publish-intent-journal.js", "services/publish-intent-authorization-service.js");
// Private updater policy/authority: no content/app IPC route; production proof
// sources remain intentionally absent until each of 15 owners is grounded.
importScripts("../../lib/update-idle-policy.js", "services/trusted-owner-authority.js");

const KRDeps = globalThis.KRDeps;
if (!KRDeps) throw new Error('runtime-deps.js must load before background.js');
const TemplateSchemaCore = KRDeps.require('KRTemplateSchemaCore');
const MessageContractRegistry = KRDeps.require('KRMessageContractRegistry');
const RenewalPolicy = KRDeps.require('KRRenewalPolicy');
const BackgroundMessageRouter = KRDeps.require('KRBackgroundMessageRouter');
const NativeUpdateStatusGateway = KRDeps.require('KRNativeUpdateStatusGateway');
const NativeStatusBridge = KRDeps.require('KRNativeStatusBridge');
const UpdateWorkflowFence = KRDeps.require('KRUpdateWorkflowFence');
const UpdateIdlePolicy = KRDeps.require('KRUpdateIdlePolicy');
const TrustedOwnerAuthority = KRDeps.require('KRTrustedOwnerAuthority');
const AtomicMV3Admission = KRDeps.require('KRAtomicMV3Admission');
const AutoPublishIntentJournal = KRDeps.require('KRAutoPublishIntentJournal');
const PublishIntentAuthorizationService = KRDeps.require('KRPublishIntentAuthorizationService');
const PersistedOwnerObserver = KRDeps.require('KRPersistedOwnerObserver');
const AdditionalOwnerObserver = KRDeps.require('KRAdditionalOwnerObserver');
const Phase4UncertaintyJournal = KRDeps.require('KRPhase4UncertaintyJournal');
const DiagnosticsService = KRDeps.require('KRDiagnosticsService');
const DiagnosticCorrelationService = KRDeps.require('KRDiagnosticCorrelationService');
const ListingUrlEvidenceService = KRDeps.require('KRListingUrlEvidenceService');
const TabRegistry = KRDeps.require('KRTabRegistry');
const ManagedNavigation = KRDeps.require('KRManagedNavigation');
const InventoryReconciliation = KRDeps.require('KRInventoryReconciliation');
const MyAdsReadiness = KRDeps.require('KRMyAdsReadiness');
const InventoryScope = KRDeps.require('KRInventoryScope');
const normalizeInventoryScope = InventoryScope.normalizeInventoryScope;
const PlatformHardening = KRDeps.require('KRPlatformHardening');
const TabLoadCoordinator = KRDeps.require('KRTabLoadCoordinator');
const ProfileRepository = KRDeps.require('KRProfileRepository');
const InventoryRepository = KRDeps.require('KRInventoryRepository');
const InventoryImageStore = KRDeps.require('KRInventoryImageStore');
const InventoryCaptureService = KRDeps.require('KRInventoryCaptureService');
const InventoryRefreshService = KRDeps.require('KRInventoryRefreshService');
const TrashService = KRDeps.require('KRTrashService');
const TrashManagementController = KRDeps.require('KRTrashManagementController');
const ManagedTabWorkerService = KRDeps.require('KRManagedTabWorkerService');
const ContentConnectionManager = KRDeps.require('KRContentConnectionManager');
const AccountProbeService = KRDeps.require('KRAccountProbeService');
const ProfileManagementController = KRDeps.require('KRProfileManagementController');
const AccountSessionController = KRDeps.require('KRAccountSessionController');
const ManualListingNavigationController = KRDeps.require('KRManualListingNavigationController');
const PlatformSafetyController = KRDeps.require('KRPlatformSafetyController');
const WorkflowEmergencyResetController = KRDeps.require('KRWorkflowEmergencyResetController');
const TabLifecycleObserver = KRDeps.require('KRTabLifecycleObserver');
const BulkRunGuard = KRDeps.require('KRBulkRunGuard');
const SingleInventoryController = KRDeps.require('KRSingleInventoryController');
const BulkInventoryController = KRDeps.require('KRBulkInventoryController');
const MassRenewalController = KRDeps.require('KRMassRenewalController');
const MassRenewalWorkflowController = KRDeps.require('KRMassRenewalWorkflowController');
const RenewalVerificationService = KRDeps.require('KRRenewalVerificationService');
const RenewalStateRepository = KRDeps.require('KRRenewalStateRepository');
const RenewalWorkflowController = KRDeps.require('KRRenewalWorkflowController');
const RenewalPhase1RetryService = KRDeps.require('KRRenewalPhase1RetryService');
const TemplateFillService = KRDeps.require('KRTemplateFillService');
const InsertionLockService = KRDeps.require('KRInsertionLockService');
const TemplateFillController = KRDeps.require('KRTemplateFillController');
const TrashTemplatePublishDetectionService = KRDeps.require('KRTrashTemplatePublishDetectionService');
const ArchiveInsertionService = KRDeps.require('KRArchiveInsertionService');
const ArchiveInsertionController = KRDeps.require('KRArchiveInsertionController');
const RemoteDeleteReplacementService = KRDeps.require('KRRemoteDeleteReplacementService');
const PublishedInventoryResolver = KRDeps.require('KRPublishedInventoryResolver');
const DiagnosticExportService = KRDeps.require('KRDiagnosticExportService');
const PublicListingEvidenceService = KRDeps.require('KRPublicListingEvidenceService');
const RenewalPublicEvidenceCoordinator = KRDeps.require('KRRenewalPublicEvidenceCoordinator');

const DB_NAME = "kleinanzeigen-renewal";
const DB_VERSION = 2;
const INVENTORY_STORE = "inventories";
const IMAGE_STORE = "images";
const MAX_DIAGNOSTICS = 2500;
const DIAGNOSTICS_KEY = "diagnosticsV2";
const DIAGNOSTIC_RETENTION_MS = 14 * 24 * 60 * 60 * 1000;
const GALLERY_DIAGNOSTICS_KEY = "galleryDiagnosticsV1";
const DIAGNOSTIC_BOUNDARY_KEY = "diagnosticBoundaryV1";
const ACCOUNT_GATE_DIAGNOSTIC_STATE_KEY = "accountGateDiagnosticStateV1";
const GALLERY_DIAGNOSTIC_RETENTION_MS = 24 * 60 * 60 * 1000;
const MAX_GALLERY_DIAGNOSTICS = 8;
const APP_WINDOW_SESSION_KEY = "appWindowId";
const APP_PAGE = "src/app/app.html";
const APP_WINDOW_INITIAL_WIDTH = 1180;
const APP_WINDOW_INITIAL_HEIGHT = 900;
const BULK_RETRY_TIMEOUT_MS = 90000;
const BULK_ITEM_HARD_TIMEOUT_MS = 110000;
const BULK_RUN_WATCHDOG_TICK_MS = 15000;
const BULK_RUN_RUNTIME_LEASE_KEY = "bulkRunRuntimeLeaseV1";
const RUNTIME_EPOCH_KEY = "runtimeEpochV1";
const BULK_RETRY_POLL_MS = 500;
const BULK_WORKER_TAB_CREATE_MAX_ATTEMPTS = 2;
const BULK_WORKER_TAB_CREATE_RETRY_MS = 200;
const CONTENT_SCRIPT_FILES = ["src/shared/runtime-deps.js", "src/shared/message-contract-registry.js", "src/shared/managed-navigation.js", "src/shared/platform-hardening.js", "src/content/platform-guard-content.js", "src/content/image-extractor.js", "src/content/form-extractor.js", "src/shared/template-schema-core.js", "src/content/paid-insertion-guard.js", "src/content/template-category-flow.js", "src/content/template-form-fields.js", "src/content/template-image-upload.js", "src/content/template-verification.js", "src/content/template-schema-preflight.js", "src/content/template-publish-flow.js", "src/content/template-filler.js", "src/shared/my-ads-readiness.js", "src/content/inventory-roster-parser.js", "src/content/inventory-readiness.js", "src/content/inventory-status-overlay.js", "src/content/inventory-delete-operations.js", "src/content/inventory-run-loop.js", "src/content/inventory-runner.js", "src/content/content.js"];
const CONTENT_BOOTSTRAP_WAITS_MS = [80, 140, 240, 400, 650];
const CONTENT_BOOTSTRAP_NAVIGATION_WAIT_MS = 30000;
const DIAGNOSTIC_BATCH_FLUSH_MS = 1200;
const DIAGNOSTIC_BATCH_MAX_PENDING = 120;
const MASS_RENEWAL_PROGRESS_FLUSH_MS = 1500;
const READONLY_METADATA_TIMEOUT_MS = 15000;
const RENEWAL_PUBLIC_READONLY_READINESS_TIMEOUT_MS = 30000;
const RENEWAL_DIRECT_READONLY_TIMEOUT_MS = 3500;
const TAB_LOAD_TIMEOUT_DEFAULT_MS = 30000;
const TAB_LOAD_TIMEOUT_RENEWAL_MS = 45000;
const TAB_LOAD_TIMEOUT_PHASE4_MS = 60000;
const TAB_LOAD_SAFETY_POLL_MS = 2000;
const ACCOUNT_PROBE_NAVIGATION_TIMEOUT_MS = 12000;
const ACCOUNT_PROBE_MAX_ATTEMPTS = 2;
const ACCOUNT_PROBE_RETRY_DELAY_MS = 250;
const MANAGED_WORKER_TOMBSTONE_MS = TabRegistry.DEFAULT_TOMBSTONE_MS;
const TAB_ROLES = TabRegistry.ROLES;
const TAB_STATES = TabRegistry.STATES;
const tabRegistry = TabRegistry.create({ storageSession: chrome.storage.session, tombstoneMs: MANAGED_WORKER_TOMBSTONE_MS });
const PROFILES_KEY = "profilesV1";
const ACTIVE_PROFILE_KEY = "activeDetectedProfileV1";
const SELECTED_PROFILE_KEY = "selectedInventoryProfileV1";
const UNASSIGNED_PROFILE_ID = "__unassigned__";
const RENEWAL_SESSIONS_KEY = "renewalSessionsV1";
const ARCHIVE_INSERTION_SESSIONS_KEY = "archiveInsertionSessionsV1";
const ARCHIVE_INSERTION_SESSION_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const RENEWAL_MODE_KEY = "renewalModeV1";
const RENEWAL_FAST_MODE_ACK_KEY = "renewalFastModeAcknowledgedV1";
const RENEWAL_PHASE_ATTEMPTS_KEY = "renewalPhaseAttemptsV1";
const RENEWAL_PHASE_ATTEMPTS_MIN = RenewalPolicy.RENEWAL_PHASE_ATTEMPTS_MIN;
const RENEWAL_PHASE_ATTEMPTS_MAX = RenewalPolicy.RENEWAL_PHASE_ATTEMPTS_MAX;
const RENEWAL_PHASE_ATTEMPTS_DEFAULT = RenewalPolicy.RENEWAL_PHASE_ATTEMPTS_DEFAULT;
const RENEWAL_MODE_SAFE = RenewalPolicy.RENEWAL_MODE_SAFE;
const RENEWAL_MODE_FAST = RenewalPolicy.RENEWAL_MODE_FAST;
const INVENTORY_SCOPE_ALL = "all";
const INVENTORY_SCOPE_NEW_ONLY = "new-only";
const RENEWAL_SESSION_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const MASS_RENEWAL_BATCH_KEY = "massRenewalBatchV1";
const MASS_RENEWAL_MAX_ITEMS = 10;
const MASS_RENEWAL_BATCH_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
const MASS_RENEWAL_WATCHDOG_STALE_MS = 5 * 60 * 1000;
const MASS_RENEWAL_WATCHDOG_TICK_MS = 20 * 1000;
const TRASH_RETENTION_MS = 30 * 24 * 60 * 60 * 1000; // Legacy 30-day fallback for older contracts.
const APP_NOTICE_KEY = "appNoticeV1";
const PLATFORM_ACCESS_RESTRICTION_KEY = "platformAccessRestrictionV1";
const PLATFORM_ACCESS_RESTRICTION_ERROR_CODE = "KR_PLATFORM_ACCESS_RESTRICTED";
const MY_ADS_PROJECTS_URL = 'https://www.kleinanzeigen.de/m-meine-anzeigen.html?tab=PROJECTS';
const FRESH_RECONCILIATION_SOURCE_MAX_ATTEMPTS = Number(InventoryReconciliation?.FRESH_RECONCILIATION_SOURCE_MAX_ATTEMPTS || 2);
const FRESH_BULK_SOURCE_MAX_ATTEMPTS = Number(MyAdsReadiness?.FRESH_SOURCE_MAX_ATTEMPTS || 2);
const CORRELATION_CONTEXT_FIELDS = Object.freeze([
  'operationId', 'parentOperationId', 'renewalId', 'fillId', 'bulkRunId', 'runId', 'massBatchId', 'archiveInsertionId'
]);

let renewalStateRepository = null;
function requireRenewalStateRepository() {
  if (!renewalStateRepository) renewalStateRepository = RenewalStateRepository.create({
    storageLocal: chrome.storage.local, sessionsKey: RENEWAL_SESSIONS_KEY, maxAgeMs: RENEWAL_SESSION_MAX_AGE_MS,
    normalizeRenewalMode, renewalMaxPhaseAttempts
  });
  return renewalStateRepository;
}

let templateFillService = null;
function requireTemplateFillService() {
  if (!templateFillService) templateFillService = TemplateFillService.create({
    storageLocal: chrome.storage.local, sessionsKey: TEMPLATE_FILL_SESSIONS_KEY, maxAgeMs: TEMPLATE_FILL_MAX_AGE_MS,
    logDiagnostic, publicAvailabilityPending, inventoryImageSetExplicitlyEmpty, getInventory, getInventoryImage, btoaFn: globalThis.btoa
  });
  return templateFillService;
}

let insertionLockService = null;
function requireInsertionLockService() {
  if (!insertionLockService) insertionLockService = InsertionLockService.create({
    readRenewalSessions, readArchiveInsertionSessions, readFillSessions, readMassRenewalBatch,
    renewalHoldsInsertionLock, templateFillHoldsInsertionLock, getInventory, logDiagnostic
  });
  return insertionLockService;
}

let templateFillController = null;
function requireTemplateFillController() {
  if (!templateFillController) templateFillController = TemplateFillController.create({
    readFillSessions, writeFillSessions, withTemplateFillMutation,
    isRecoverableTrashTemplateSession: session => requireTemplateFillService().isRecoverableTrashTemplateSession(session),
    resolvePublishedInventory: input => requirePublishedInventoryResolver().resolve(input),
    broadcastInventoryChanged, getInventory, isTrashRecord, assertTemplateSourceReady,
    createAutomationTab, deleteInventoryStorageRecord, delay, registerShadowTab, updateAutomationTab, logDiagnostic, correlationContext, sessionCorrelationContext,
    assertSelectedProfileMatchesLiveAccount, getInsertionLockState, assertInsertionStartAvailable, withInsertionStartGate,
    getRenewalConfiguration, normalizeRenewalMode, normalizeRenewalPhaseAttempts,
    readRenewalSessions, writeRenewalSessions, createRenewalSkeleton, persistRenewalSession,
    isTransientTemplateFillProgress, templateFillProgressSnapshot, queueMassRenewalProgress,
    readArchiveInsertionSessions, persistArchiveInsertionSession,
    recordRenewalPhaseAttemptError, canRetryRenewalPhase1, restartRenewalPhase1Attempt,
    evictTemplateImageTransfersForFill, classifyKleinanzeigenInsertionErrorUrl,
    cryptoApi: crypto, chromeApi: chrome, TemplateSchemaCore, queueMicrotaskFn: queueMicrotask,
    withAutonomousAdmission,
    TEMPLATE_TARGET_URL, TAB_ROLES, TERMINAL_TEMPLATE_FILL_STATUSES
  });
  return templateFillController;
}

let archiveInsertionService = null;
function requireArchiveInsertionService() {
  if (!archiveInsertionService) archiveInsertionService = ArchiveInsertionService.create({
    storageLocal: chrome.storage.local, sessionsKey: ARCHIVE_INSERTION_SESSIONS_KEY, maxAgeMs: ARCHIVE_INSERTION_SESSION_MAX_AGE_MS, normalizeRenewalMode,
    broadcast(snapshot, reason) {
      try { chrome.runtime.sendMessage({ type: 'ARCHIVE_INSERTION_STATE_CHANGED', reason, session: snapshot }, () => { void chrome.runtime.lastError; }); } catch {}
    }
  });
  return archiveInsertionService;
}

let remoteDeleteReplacementService = null;
function requireRemoteDeleteReplacementService() {
  if (!remoteDeleteReplacementService) remoteDeleteReplacementService = RemoteDeleteReplacementService.create({
    readRenewalSessions, writeRenewalSessions, getBulkRunState, moveInventoryToTrash, readFillSessions, writeFillSessions,
    logDiagnostic, sessionCorrelationContext, broadcastInventoryChanged, TRASH_RETENTION_MS, openDatabase, INVENTORY_STORE, IMAGE_STORE,
    isTrashRecord, normalizeRenewalMode, RENEWAL_MODE_FAST, trashRecordFrom, persistRenewalSession, tabRegistry, chromeApi: chrome,
    closeRegistryTab, TabRegistry, createManagedWorkerTab, correlationContext, MY_ADS_PROJECTS_URL, waitForTabComplete,
    TAB_LOAD_TIMEOUT_PHASE4_MS, ensureContentConnection, sendTabRequestWithBootstrap, normalizeProfileName, closeManagedWorkerTab,
    renewalMaxPhaseAttempts, isPhase4DeleteTransportInterruption, assertMassRenewalManualActionAllowed, getInventory, normalBrowserWindowId,
    renewalPhaseAttemptAvailable, renewalAttemptState, delay, renewalPhaseRetryDelayMs, logRenewalPhaseAttemptStarted,
    logRenewalPhaseAttemptFailed, isNonRetryableRenewalSafetyError, renewalAttemptDetails, setAppNotice, markMassRenewalItemSucceeded,
    IDBKeyRangeCtor: globalThis.IDBKeyRange, captureEmergencyResetGeneration, assertEmergencyResetGeneration,
    beginPhase4Attempt: current => requirePhase4UncertaintyJournal().begin(current),
    observePhase4Attempts: renewalId => requirePhase4UncertaintyJournal().observe(renewalId),
    resolvePhase4Attempt: request => requirePhase4UncertaintyJournal().resolveVerified(request)
  });
  return remoteDeleteReplacementService;
}

function normalizeCorrelationId(value) {
  const text = String(value ?? '').trim();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(text) ? text : '';
}

function correlationContext(...sources) {
  const result = {};
  for (const source of sources) {
    if (!source || typeof source !== 'object') continue;
    for (const field of CORRELATION_CONTEXT_FIELDS) {
      if (result[field]) continue;
      const value = String(source[field] ?? '').trim();
      if (value) result[field] = value;
    }
  }
  return result;
}

function sessionCorrelationContext(session, extra = {}) {
  return { ...correlationContext(session, extra), ...extra };
}

let diagnosticCorrelationService = null;
function requireDiagnosticCorrelationService() {
  if (!diagnosticCorrelationService) diagnosticCorrelationService = DiagnosticCorrelationService.create({
    correlationContext,
    storageLocal: chrome.storage.local,
    RENEWAL_SESSIONS_KEY, MASS_RENEWAL_BATCH_KEY, ARCHIVE_INSERTION_SESSIONS_KEY
  });
  return diagnosticCorrelationService;
}
async function resolveClientDiagnosticCorrelation(message = {}, sender = {}) {
  return requireDiagnosticCorrelationService().resolveClientDiagnosticCorrelation(message, sender);
}

async function withInsertionStartGate(task) { return requireInsertionLockService().withInsertionStartGate(task); }

const normalizeRenewalMode = RenewalPolicy.normalizeRenewalMode;
const normalizeRenewalPhaseAttempts = RenewalPolicy.normalizeRenewalPhaseAttempts;
const renewalMaxPhaseAttempts = RenewalPolicy.renewalMaxPhaseAttempts;
const renewalAttemptState = RenewalPolicy.renewalAttemptState;

function beginRenewalPhaseAttempt(session, phase, { attempt = null, lastError = null } = {}) {
  const phaseNumber = Number(phase);
  const key = String(phaseNumber);
  const previous = renewalAttemptState(session, phaseNumber);
  const nextAttempt = attempt == null ? previous.attempt + 1 : Number(attempt);
  session.phaseAttempts = { ...(session.phaseAttempts || {}) };
  const state = {
    attempt: Math.max(1, nextAttempt),
    attemptId: crypto.randomUUID(),
    lastError: lastError ? String(lastError).slice(0, 800) : null,
    updatedAt: new Date().toISOString()
  };
  session.phaseAttempts[key] = state;
  return state;
}

function recordRenewalPhaseAttemptError(session, phase, error) {
  const key = String(Number(phase));
  const current = renewalAttemptState(session, phase);
  session.phaseAttempts = { ...(session.phaseAttempts || {}) };
  session.phaseAttempts[key] = {
    ...current,
    lastError: String(error?.message || error || '').slice(0, 800) || null,
    updatedAt: new Date().toISOString()
  };
  return session.phaseAttempts[key];
}

const renewalPhaseAttemptAvailable = RenewalPolicy.renewalPhaseAttemptAvailable;

const renewalAttemptDetails = RenewalPolicy.renewalAttemptDetails;

const isNonRetryableRenewalSafetyError = RenewalPolicy.isNonRetryableRenewalSafetyError;

const renewalPhaseRetryDelayMs = RenewalPolicy.renewalPhaseRetryDelayMs;

function resetRenewalPhaseAttempts(session, phases = []) {
  if (!session || typeof session !== 'object') return session;
  session.phaseAttempts = { ...(session.phaseAttempts || {}) };
  for (const phase of phases) delete session.phaseAttempts[String(Number(phase))];
  return session;
}

async function logRenewalPhaseAttemptStarted(session, phase, eventName, operation, extra = {}) {
  const state = beginRenewalPhaseAttempt(session, phase);
  await persistRenewalSession(session);
  await logDiagnostic('info', eventName, {
    renewalId: session.renewalId,
    sourceAdId: session.sourceAdId,
    newAdId: session.newAdId || null,
    ...renewalAttemptDetails(session, phase),
    ...extra
  }, {
    module: 'background',
    operation,
    context: sessionCorrelationContext(session, { renewalId: session.renewalId, adId: session.newAdId || session.sourceAdId })
  }).catch(() => {});
  return state;
}

async function logRenewalPhaseAttemptFailed(session, phase, eventName, operation, error, extra = {}) {
  const state = recordRenewalPhaseAttemptError(session, phase, error);
  await persistRenewalSession(session).catch(() => {});
  await logDiagnostic('warning', eventName, {
    renewalId: session.renewalId,
    sourceAdId: session.sourceAdId,
    newAdId: session.newAdId || null,
    ...renewalAttemptDetails(session, phase),
    message: String(error?.message || error || '').slice(0, 800),
    retryAvailable: renewalPhaseAttemptAvailable(session, phase),
    ...extra
  }, {
    module: 'background',
    operation,
    context: sessionCorrelationContext(session, { renewalId: session.renewalId, adId: session.newAdId || session.sourceAdId })
  }).catch(() => {});
  return state;
}

function extractHttpErrorCode(...values) {
  for (const value of values) {
    const match = String(value || '').match(/(?:^|\D)([45]\d{2})(?:\D|$)/);
    if (match) return Number(match[1]);
  }
  return null;
}

function classifyKleinanzeigenInsertionErrorUrl(rawUrl, evidence = {}) {
  try {
    const url = new URL(String(rawUrl || ''));
    const host = String(url.hostname || '').toLowerCase();
    if (url.protocol !== 'https:' || (host !== 'kleinanzeigen.de' && !host.endsWith('.kleinanzeigen.de'))) {
      return { isError: false, errorCode: null, reason: null, path: url.pathname || null };
    }
    const path = String(url.pathname || '');
    const title = String(evidence?.title || '');
    const heading = String(evidence?.heading || '');
    const markerText = `${path} ${url.search} ${title} ${heading}`;
    const errorCode = extractHttpErrorCode(markerText);
    const knownInsertionErrorPath = path === '/anzeige-aufgeben-fehler.html';
    const semanticErrorPath = /(?:fehler|error)/i.test(path) && (/(?:anzeige|aufgeben|inser)/i.test(path) || Boolean(errorCode));
    const explicitHttpErrorPath = /(?:^|[\/_-])(?:4\d{2}|5\d{2})(?:[\/_\.-]|$)/.test(path) && /(?:fehler|error|status)/i.test(markerText);
    const strongTitle = /(?:fehler|error|bad request|internal server error|service unavailable|gateway timeout)/i.test(`${title} ${heading}`) && Boolean(errorCode);
    const isError = knownInsertionErrorPath || semanticErrorPath || explicitHttpErrorPath || strongTitle;
    return { isError, errorCode: isError ? errorCode : null, reason: knownInsertionErrorPath ? 'known-insertion-error-path' : semanticErrorPath ? 'semantic-error-path' : explicitHttpErrorPath ? 'http-error-path' : strongTitle ? 'http-error-title' : null, path: path || null };
  } catch {
    return { isError: false, errorCode: null, reason: null, path: null };
  }
}

async function getRenewalConfiguration() {
  const stored = await chrome.storage.local.get([RENEWAL_MODE_KEY, RENEWAL_FAST_MODE_ACK_KEY, RENEWAL_PHASE_ATTEMPTS_KEY]);
  return {
    renewalMode: normalizeRenewalMode(stored?.[RENEWAL_MODE_KEY]),
    fastModeAcknowledged: stored?.[RENEWAL_FAST_MODE_ACK_KEY] === true,
    maxPhaseAttempts: normalizeRenewalPhaseAttempts(stored?.[RENEWAL_PHASE_ATTEMPTS_KEY])
  };
}

async function setRenewalMode(message) {
  const renewalMode = normalizeRenewalMode(message?.renewalMode);
  const patch = { [RENEWAL_MODE_KEY]: renewalMode };
  if (renewalMode === RENEWAL_MODE_FAST && message?.acknowledgeFastMode === true) patch[RENEWAL_FAST_MODE_ACK_KEY] = true;
  await chrome.storage.local.set(patch);
  const configuration = await getRenewalConfiguration();
  await logDiagnostic('info', 'RENEWAL_MODE_CHANGED', {
    renewalMode: configuration.renewalMode,
    fastModeAcknowledged: configuration.fastModeAcknowledged
  }, { module: 'background', operation: 'renewal-configuration' }).catch(() => {});
  return configuration;
}

async function setRenewalPhaseAttempts(message) {
  const maxPhaseAttempts = normalizeRenewalPhaseAttempts(message?.maxPhaseAttempts);
  await chrome.storage.local.set({ [RENEWAL_PHASE_ATTEMPTS_KEY]: maxPhaseAttempts });
  const configuration = await getRenewalConfiguration();
  await logDiagnostic('info', 'RENEWAL_PHASE_ATTEMPTS_CHANGED', {
    maxPhaseAttempts: configuration.maxPhaseAttempts
  }, { module: 'background', operation: 'renewal-configuration' }).catch(() => {});
  return configuration;
}

let managedTabWorkerService = null;
function requireManagedTabWorkerService() {
  if (!managedTabWorkerService) {
    managedTabWorkerService = ManagedTabWorkerService.create({
      tabRegistry,
      chromeTabs: chrome.tabs,
      createAutomationTab: options => createAutomationTab(options),
      updateAutomationTab: (tabId, properties) => updateAutomationTab(tabId, properties),
      isGoneError: error => TabRegistry.isGoneError(error),
      isDiscardedError: error => TabRegistry.isDiscardedError(error)
    });
  }
  return managedTabWorkerService;
}
async function registerManagedWorkerTab(tabId, kind = 'worker', owner = {}) { return requireManagedTabWorkerService().registerManagedWorkerTab(tabId, kind, owner); }
async function markManagedWorkerTabClosed(tabId) { return requireManagedTabWorkerService().markManagedWorkerTabClosed(tabId); }
async function getManagedWorkerTabIds() { return requireManagedTabWorkerService().getManagedWorkerTabIds(); }
async function getTabRegistrySnapshot() { return requireManagedTabWorkerService().getTabRegistrySnapshot(); }
async function createManagedWorkerTab(createOptions, kind, owner = {}) { return requireManagedTabWorkerService().createManagedWorkerTab(createOptions, kind, owner); }
async function closeRegistryTab(tabId, reason = 'workflow-close', label = 'Kleinanzeigen-Tab') { return requireManagedTabWorkerService().closeRegistryTab(tabId, reason, label); }
async function closeRegistryTabs(tabIds, reason = 'workflow-close', label = 'Kleinanzeigen-Tab') { return requireManagedTabWorkerService().closeRegistryTabs(tabIds, reason, label); }
async function closeManagedWorkerTab(tabId) { return requireManagedTabWorkerService().closeManagedWorkerTab(tabId); }
async function registerShadowTab(tabId, role, owner = {}, options = {}) { return requireManagedTabWorkerService().registerShadowTab(tabId, role, owner, options); }

function bulkRunOwnerExpectation(state = {}) {
  const operationId = String(state?.operationId || '').trim();
  const bulkRunId = String(state?.bulkRunId || state?.runId || '').trim();
  const runId = String(state?.runId || state?.bulkRunId || '').trim();
  const ownerId = runId || bulkRunId || operationId;
  return {
    ...(operationId ? { operationId } : {}),
    ...(bulkRunId ? { bulkRunId } : {}),
    ...(runId ? { runId } : {}),
    ownerType: 'bulk',
    ...(ownerId ? { ownerId } : {})
  };
}

function bulkRunOwnsRegistryTab(entry, state = {}) {
  return Boolean(entry && TabRegistry.ownerMatches(entry.owner || {}, bulkRunOwnerExpectation(state)));
}

function bulkRunActiveForRegistry(state) {
  return Boolean(state && (String(state.status || '') === 'running' || String(state.retryAdId || '')));
}

async function releaseBulkSourceOwnership(state, reason = 'bulk-terminal') {
  const sourceTabId = Number(state?.sourceTabId || 0);
  if (!sourceTabId) return { released: false, reason: 'missing-source-tab', entry: null };
  const entry = await tabRegistry.get(sourceTabId).catch(() => null);
  if (!entry) return { released: false, reason: 'missing', entry: null };
  if (!bulkRunOwnsRegistryTab(entry, state)) return { released: false, reason: 'owner-mismatch', entry };
  const result = await tabRegistry.releaseOwnership(sourceTabId, bulkRunOwnerExpectation(state));
  if (result?.released) {
    await logDiagnostic('info', 'TAB_REGISTRY_OWNERSHIP_RELEASED', {
      tabId: sourceTabId,
      role: entry.role || null,
      ownerType: 'bulk',
      ownerId: String(state?.runId || state?.bulkRunId || state?.operationId || '') || null,
      reason
    }, { module: 'background', operation: 'tab-registry', context: sessionCorrelationContext(state, { sourceTabId }) }).catch(() => {});
  }
  return result;
}

async function reconcileTabRegistry() {
  const [tabs, stored] = await Promise.all([
    chrome.tabs.query({ url: ['https://www.kleinanzeigen.de/*', 'https://kleinanzeigen.de/*'] }).catch(() => []),
    chrome.storage.local.get(['bulkInventoryRun', 'templateFillSessions', RENEWAL_SESSIONS_KEY, ARCHIVE_INSERTION_SESSIONS_KEY]).catch(() => ({}))
  ]);
  const fills = Object.values(stored?.templateFillSessions || {}).filter(Boolean);
  const renewals = Object.values(stored?.[RENEWAL_SESSIONS_KEY] || {}).filter(Boolean);
  const archives = Object.values(stored?.[ARCHIVE_INSERTION_SESSIONS_KEY] || {}).filter(Boolean);
  const bulk = stored?.bulkInventoryRun && typeof stored.bulkInventoryRun === 'object' ? stored.bulkInventoryRun : null;
  const bulkActive = bulkRunActiveForRegistry(bulk);
  if (bulk && !bulkActive) await releaseBulkSourceOwnership(bulk, 'reconcile-terminal').catch(() => {});
  const existing = new Map((await tabRegistry.snapshot()).map(entry => [Number(entry.tabId), entry]));

  for (const tab of tabs) {
    const id = Number(tab?.id || 0);
    if (!id) continue;
    const prior = existing.get(id);
    let role = prior?.role || TabRegistry.roleForUrl(tab.url);
    let owner = prior?.owner || {};
    const fill = fills.find(item => Number(item?.targetTabId || 0) === id) || null;
    const renewal = renewals.find(item => Number(item?.targetTabId || 0) === id) || null;
    const archive = archives.find(item => Number(item?.targetTabId || 0) === id) || null;
    if (archive || fill?.archiveInsertionId) {
      role = TAB_ROLES.ARCHIVE_TARGET;
      owner = correlationContext(archive, fill);
    } else if (renewal || fill?.renewalId) {
      role = TAB_ROLES.RENEWAL_TARGET;
      owner = correlationContext(renewal, fill);
    } else if (bulkActive && Number(bulk.sourceTabId || 0) === id) {
      role = TAB_ROLES.BULK_SOURCE;
      owner = { ...correlationContext(bulk), ownerType: 'bulk', ownerId: String(bulk.runId || bulk.bulkRunId || bulk.operationId || '') };
    } else if (bulkActive && [bulk.workerTabId, bulk.metadataTabId].some(value => Number(value || 0) === id)) {
      role = TAB_ROLES.BULK_WORKER;
      owner = { ...correlationContext(bulk), ownerType: 'bulk', ownerId: String(bulk.runId || bulk.bulkRunId || bulk.operationId || '') };
    }
    await tabRegistry.observeTab(tab, { role, managed: prior?.managed ?? false, owner }).catch(() => {});
  }
  return tabRegistry.snapshot();
}

function isKleinanzeigenTabUrl(rawUrl) {
  try {
    const url = new URL(String(rawUrl || ''));
    return url.protocol === 'https:' && /^(?:www\.)?kleinanzeigen\.de$/i.test(url.hostname);
  } catch { return false; }
}

async function reactivateDiscardedTabs(message = {}) { return requireManagedTabWorkerService().reactivateDiscardedTabs(message); }

function broadcastInventoryChanged(reason, details = {}) {
  try {
    chrome.runtime.sendMessage({ type: 'INVENTORY_DATA_CHANGED', reason, details }, () => {
      void chrome.runtime.lastError;
    });
  } catch { /* UI notification is best-effort only. */ }
}

function isTrashRecord(record) { return requireTrashService().isTrashRecord(record); }

function trashRecordFrom(record, reason = 'manual', context = {}, at = new Date()) { return requireTrashService().trashRecordFrom(record, reason, context, at); }

async function setAppNotice(notice) {
  const value = notice && typeof notice === 'object' ? { ...notice, createdAt: notice.createdAt || new Date().toISOString() } : null;
  if (value) await chrome.storage.local.set({ [APP_NOTICE_KEY]: value });
  else await chrome.storage.local.remove(APP_NOTICE_KEY);
  return value;
}

async function getAppNotice() {
  const stored = await chrome.storage.local.get(APP_NOTICE_KEY);
  return stored?.[APP_NOTICE_KEY] || null;
}

async function dismissAppNotice(message) {
  const current = await getAppNotice();
  const expectedId = String(message?.noticeId || '');
  if (!expectedId || !current || String(current.id || '') === expectedId) await chrome.storage.local.remove(APP_NOTICE_KEY);
  return { dismissed: true };
}
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
let emergencyResetGeneration = 0;
function captureEmergencyResetGeneration() { return emergencyResetGeneration; }
function assertEmergencyResetGeneration(expectedGeneration, operation = 'workflow') {
  if (Number(expectedGeneration) === emergencyResetGeneration) return true;
  const error = new Error('Der Vorgang wurde durch einen lokalen Notfall-Reset beendet.');
  error.code = 'KR_EMERGENCY_RESET_GENERATION_CHANGED';
  error.operation = operation;
  throw error;
}
function bumpEmergencyResetGeneration() { emergencyResetGeneration += 1; return emergencyResetGeneration; }

const PLATFORM_REMOTE_ACTION_TYPES = new Set([
  'ENSURE_CONTENT_CONNECTION', 'REACTIVATE_DISCARDED_TABS',
  'OPEN_EDIT_AD', 'OPEN_READONLY_AD', 'PROBE_LIVE_KLEINANZEIGEN_ACCOUNT',
  'REFRESH_INVENTORY', 'CAPTURE_SINGLE_INVENTORY', 'RETRY_RENEWAL_VERIFICATION',
  'START_BULK_INVENTORY_OPERATION', 'BULK_INIT_RUN',
  'BULK_BEGIN_RECONCILIATION', 'BULK_OPEN_WORKER', 'BULK_EXTRACT_SAVE_WORKER',
  'RETRY_BULK_FAILURE', 'START_MASS_RENEWAL_BATCH', 'RETRY_MASS_RENEWAL_ITEM',
  'START_TEMPLATE_FILL', 'START_ARCHIVE_INSERTION', 'START_TRASH_TEMPLATE_FILL'
]);

let platformSafetyController = null;
function requirePlatformSafetyController() {
  if (!platformSafetyController) {
    platformSafetyController = PlatformSafetyController.create({
      remoteActionTypes: PLATFORM_REMOTE_ACTION_TYPES,
      restrictionKey: PLATFORM_ACCESS_RESTRICTION_KEY,
      errorCode: PLATFORM_ACCESS_RESTRICTION_ERROR_CODE,
      storageLocal: chrome.storage.local,
      chromeTabs: chrome.tabs,
      runtime: chrome.runtime,
      platformHardening: PlatformHardening,
      logDiagnostic,
      getBulkRunState, writeBulkRunState,
      closeRegistryTabs, closeRegistryTab, releaseBulkSourceOwnership,
      readRenewalSessions, writeRenewalSessions,
      readArchiveInsertionSessions, writeArchiveInsertionSessions,
      readFillSessions, writeFillSessions,
      readMassRenewalBatch, writeMassRenewalBatch, touchMassRenewalItemProgress,
      getTabRegistrySnapshot,
      goneState: TAB_STATES.GONE,
      bulkWorkerRole: TAB_ROLES.BULK_WORKER,
      broadcastInventoryChanged
    });
  }
  return platformSafetyController;
}
async function readPlatformAccessRestriction() { return requirePlatformSafetyController().readPlatformAccessRestriction(); }
function platformAccessRestrictionError(state = null) { return requirePlatformSafetyController().platformAccessRestrictionError(state); }
async function assertPlatformAccessAllowed(context = {}) { return requirePlatformSafetyController().assertPlatformAccessAllowed(context); }
async function assertPlatformAccessAllowedForRequest(message = {}) { return requirePlatformSafetyController().assertPlatformAccessAllowedForRequest(message); }
async function createAutomationTab(options) { return requirePlatformSafetyController().createAutomationTab(options); }
async function updateAutomationTab(tabId, updateProperties) { return requirePlatformSafetyController().updateAutomationTab(tabId, updateProperties); }
async function reloadAutomationTab(tabId, reloadProperties = undefined) { return requirePlatformSafetyController().reloadAutomationTab(tabId, reloadProperties); }
function broadcastPlatformAccessRestrictionChanged(state) { return requirePlatformSafetyController().broadcastPlatformAccessRestrictionChanged(state); }
async function applyPlatformSafetyStop(state) { return requirePlatformSafetyController().applyPlatformSafetyStop(state); }
async function activatePlatformAccessRestriction(message = {}, sender = {}) { return requirePlatformSafetyController().activatePlatformAccessRestriction(message, sender); }
async function clearPlatformAccessRestriction() { return requirePlatformSafetyController().clearPlatformAccessRestriction(); }

async function openOrFocusAppWindow() {
  const stored = await chrome.storage.session.get(APP_WINDOW_SESSION_KEY).catch(() => ({}));
  const existingId = Number(stored?.[APP_WINDOW_SESSION_KEY] || 0);
  if (existingId) {
    try {
      const existing = await chrome.windows.get(existingId);
      await chrome.windows.update(existing.id, { focused: true });
      await logDiagnostic('info', 'APP_WINDOW_FOCUSED', { windowId: existing.id }, { module: 'background', operation: 'app-window' }).catch(() => {});
      return { windowId: existing.id, reused: true };
    } catch {
      await chrome.storage.session.remove(APP_WINDOW_SESSION_KEY).catch(() => {});
    }
  }
  const created = await chrome.windows.create({
    url: chrome.runtime.getURL(APP_PAGE),
    type: "popup",
    focused: true,
    width: APP_WINDOW_INITIAL_WIDTH,
    height: APP_WINDOW_INITIAL_HEIGHT
  });
  if (!created?.id) throw new Error("App-Fenster konnte nicht geöffnet werden.");
  await chrome.storage.session.set({ [APP_WINDOW_SESSION_KEY]: created.id });
  await logDiagnostic('info', 'APP_WINDOW_OPENED', { windowId: created.id, width: APP_WINDOW_INITIAL_WIDTH, height: APP_WINDOW_INITIAL_HEIGHT }, { module: 'background', operation: 'app-window' }).catch(() => {});
  return { windowId: created.id, reused: false };
}

let inventoryRepository = null;
let inventoryImageStore = null;
let trashManagementController = null;

function requireInventoryRepository() {
  if (inventoryRepository) return inventoryRepository;
  if (!InventoryRepository?.create) throw new Error('inventory-repository.js must load before inventory storage is used');
  inventoryRepository = InventoryRepository.create({
    indexedDB, IDBKeyRange, dbName: DB_NAME, dbVersion: DB_VERSION,
    inventoryStore: INVENTORY_STORE, imageStore: IMAGE_STORE,
    unassignedProfileId: UNASSIGNED_PROFILE_ID
  });
  return inventoryRepository;
}

function requireInventoryImageStore() {
  if (inventoryImageStore) return inventoryImageStore;
  if (!InventoryImageStore?.create) throw new Error('inventory-image-store.js must load before inventory images are used');
  const repository = requireInventoryRepository();
  inventoryImageStore = InventoryImageStore.create({
    openSharedDatabase: repository.openSharedDatabase,
    openDatabase: repository.openDatabase,
    imageStore: IMAGE_STORE,
    IDBKeyRange
  });
  return inventoryImageStore;
}

function requireTrashManagementController() {
  if (!trashManagementController) trashManagementController = TrashManagementController.create({
    TrashService, inventoryRepository: requireInventoryRepository(),
    storageLocal: chrome.storage.local, selectedProfileKey: SELECTED_PROFILE_KEY,
    logDiagnostic, broadcastInventoryChanged, withAutonomousAdmission
  });
  return trashManagementController;
}
function requireTrashService() { return requireTrashManagementController().service; }

function requireDiagnosticsService() {
  if (diagnosticsService) return diagnosticsService;
  if (!DiagnosticsService?.create) throw new Error('diagnostics-service.js must load before diagnostics are used');
  diagnosticsService = DiagnosticsService.create({
    storageLocal: chrome.storage.local,
    randomUUID: () => crypto.randomUUID(),
    correlationContext,
    getResetBlocker: diagnosticResetBlocker,
    maxDiagnostics: MAX_DIAGNOSTICS,
    diagnosticsKey: DIAGNOSTICS_KEY,
    retentionMs: DIAGNOSTIC_RETENTION_MS,
    galleryKey: GALLERY_DIAGNOSTICS_KEY,
    boundaryKey: DIAGNOSTIC_BOUNDARY_KEY,
    galleryRetentionMs: GALLERY_DIAGNOSTIC_RETENTION_MS,
    maxGalleryDiagnostics: MAX_GALLERY_DIAGNOSTICS,
    batchFlushMs: DIAGNOSTIC_BATCH_FLUSH_MS,
    batchMaxPending: DIAGNOSTIC_BATCH_MAX_PENDING
  });
  return diagnosticsService;
}

function currentDiagnosticSessionId() { return requireDiagnosticsService().sessionId(); }
function redactUrl(raw) { return requireDiagnosticsService().redactUrl(raw); }
function sanitizeDiagnosticValue(value, key = '', depth = 0) { return requireDiagnosticsService().sanitize(value, key, depth); }
function representedDiagnosticEventCount(events) { return requireDiagnosticsService().representedEventCount(events); }
function readDiagnostics() { return requireDiagnosticsService().read(); }
function flushDiagnosticBuffer() { return requireDiagnosticsService().flush(); }
function logDiagnostic(level, event, details = {}, meta = {}) { return requireDiagnosticsService().log(level, event, details, meta); }
function storeGalleryDiagnostic(message, sender) { return requireDiagnosticsService().storeGallery(message, sender); }
function readRecentGalleryDiagnostics() { return requireDiagnosticsService().readRecentGallery(); }
function readDiagnosticOccupancy() { return requireDiagnosticsService().occupancy(); }
function resetDiagnostics() { return requireDiagnosticsService().reset(); }

async function logClientDiagnostic(message, sender) {
  const severity = ['info', 'warning', 'error'].includes(message?.severity) ? message.severity : 'info';
  const providedContext = message?.context && typeof message.context === 'object' ? message.context : {};
  const resolvedCorrelation = await resolveClientDiagnosticCorrelation(message, sender);
  return logDiagnostic(severity, message?.event || 'CLIENT_EVENT', message?.details || {}, {
    module: message?.module || 'client',
    operation: message?.operation || '',
    context: {
      ...providedContext,
      senderTabId: sender?.tab?.id ?? null,
      ...resolvedCorrelation
    }
  }).then(() => ({ logged: true }));
}

async function diagnosticResetBlocker() {
  const [bulk, insertionLock, massBatch] = await Promise.all([
    getBulkRunState().catch(() => null),
    getInsertionLockState().catch(() => ({ locked: false })),
    readMassRenewalBatch().catch(() => null)
  ]);
  if (bulk && (String(bulk.status || '') === 'running' || Boolean(bulk.retryAdId) || String(bulk.stage || '').startsWith('reconciliation-'))) {
    return 'Diagnose kann während einer laufenden Erfassung nicht zurückgesetzt werden.';
  }
  if (insertionLock?.locked) return 'Diagnose kann während eines laufenden Neu-Inserierens nicht zurückgesetzt werden.';
  if (String(massBatch?.status || '') === 'running') return 'Diagnose kann während eines laufenden Neu-Inserierens nicht zurückgesetzt werden.';
  return '';
}

function normalizeProfileName(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

let profileManagementController = null;
function requireProfileManagementController() {
  if (!profileManagementController) profileManagementController = ProfileManagementController.create({
    ProfileRepository,
    storageLocal: chrome.storage.local,
    profilesKey: PROFILES_KEY,
    activeProfileKey: ACTIVE_PROFILE_KEY,
    selectedProfileKey: SELECTED_PROFILE_KEY,
    unassignedProfileId: UNASSIGNED_PROFILE_ID,
    normalizeProfileName,
    randomUUID: () => crypto.randomUUID(),
    purgeExpiredTrash,
    readAllInventoryRecords,
    getBulkRunState,
    isTrashRecord,
    readInventoryRecordsForProfile,
    readRenewalSessions,
    readMassRenewalBatch,
    getInventoryRepository: requireInventoryRepository,
    logDiagnostic,
    broadcastInventoryChanged,
    invalidateTrashPurgeSchedule
  });
  return profileManagementController;
}

async function readProfiles() { return requireProfileManagementController().readProfiles(); }

async function getProfileState() { return requireProfileManagementController().getProfileState(); }
async function setSelectedProfile(message) { return requireProfileManagementController().setSelectedProfile(message); }
async function prepareProfileBackupImport(message) { return requireProfileManagementController().prepareProfileBackupImport(message); }
async function finalizeProfileBackupImport(message) { return requireProfileManagementController().finalizeProfileBackupImport(message); }
async function deleteProfile(message) { return requireProfileManagementController().deleteProfile(message); }
async function ensureProfile(profileName) { return requireProfileManagementController().ensureProfile(profileName); }
async function recognizeProfile(message) { return requireProfileManagementController().recognizeProfile(message); }
async function assignUnprofiledInventories(message) { return requireProfileManagementController().assignUnprofiledInventories(message); }

if (chrome?.storage?.local) void logDiagnostic('info', 'DIAGNOSTIC_SESSION_STARTED', { sessionId: currentDiagnosticSessionId() }, { module: 'background', operation: 'diagnostic-session' }).catch(() => {});

let inventoryCaptureService = null;
function requireInventoryCaptureService() {
  if (!inventoryCaptureService) inventoryCaptureService = InventoryCaptureService.create({
    templateSchemaCore: TemplateSchemaCore,
    logDiagnostic,
    commitInventory: (record, stagedImages) => requireInventoryRepository().commit(record, stagedImages),
    getInventory,
    broadcastInventoryChanged
  });
  return inventoryCaptureService;
}
async function saveInventory(extracted, options = {}) {
  return requireInventoryCaptureService().saveInventory(extracted, options);
}

async function readAllInventoryRecords() { return requireInventoryRepository().readAll(); }

async function readInventoryRecordsForProfile(profileId) { return requireInventoryRepository().readForProfile(profileId); }

function invalidateTrashPurgeSchedule() { requireTrashService().invalidatePurgeSchedule(); }

async function purgeExpiredTrash() { return requireTrashManagementController().purgeExpiredTrash(); }

async function listInventories(profileId) { await purgeExpiredTrash(); const records = (await readInventoryRecordsForProfile(profileId)).filter(record => !isTrashRecord(record)); return records.sort((a, b) => String(b.capturedAt || '').localeCompare(String(a.capturedAt || ''))); }

async function listTrashEntries(profileId) { await purgeExpiredTrash(); return requireTrashService().list(profileId); }

async function getTrashRetentionConfiguration() { return requireTrashService().getConfiguration(); }
async function previewTrashRetentionChange(message) {
  return requireTrashService().previewRetentionChange(message?.retentionDays, message?.selectedProfileId);
}
async function commitTrashRetentionChange(message) {
  return requireTrashManagementController().commitTrashRetentionChange(message);
}

async function setAccountGateDiagnosticState(message = {}) { return requireAccountSessionController().setAccountGateDiagnosticState(message); }

let diagnosticExportService = null;
function requireDiagnosticExportService() {
  if (!diagnosticExportService) diagnosticExportService = DiagnosticExportService.create({
    chromeApi: chrome, navigatorApi: navigator, messageContractRegistry: MessageContractRegistry,
    maxDiagnostics: MAX_DIAGNOSTICS, diagnosticRetentionMs: DIAGNOSTIC_RETENTION_MS,
    diagnosticBoundaryKey: DIAGNOSTIC_BOUNDARY_KEY, accountGateDiagnosticStateKey: ACCOUNT_GATE_DIAGNOSTIC_STATE_KEY,
    readDiagnostics, getBulkRunState, listInventories, readFillSessions, readRenewalSessions, getProfileState,
    readRecentGalleryDiagnostics, readMassRenewalBatch, sanitizeDiagnosticValue, currentDiagnosticSessionId,
    normalizeRenewalPhaseAttempts, renewalPublicSnapshot, massRenewalPublicSnapshot, redactUrl, representedDiagnosticEventCount
  });
  return diagnosticExportService;
}

const BULK_RUN_KEY = "bulkInventoryRun";
const BULK_RUN_MAX_AGE_MS = 6 * 60 * 60 * 1000;
let bulkRunGuard = null;
let bulkRuntimeRecoveryPromise = null;
function requireBulkRunGuard() {
  if (!bulkRunGuard) {
    bulkRunGuard = BulkRunGuard.create({
      storageLocal: chrome.storage.local,
      storageSession: chrome.storage.session,
      runKey: BULK_RUN_KEY,
      leaseKey: BULK_RUN_RUNTIME_LEASE_KEY,
      epochKey: RUNTIME_EPOCH_KEY,
      itemHardTimeoutMs: BULK_ITEM_HARD_TIMEOUT_MS,
      randomUUID: () => crypto.randomUUID()
    });
  }
  return bulkRunGuard;
}
async function cleanupRecoveredBulkTabs(tabIds = [], reason = 'bulk-runtime-recovery') {
  const ids = [...new Set((tabIds || []).map(value => Number(value || 0)).filter(Boolean))];
  if (!ids.length) return;
  await closeRegistryTabs(ids, reason, 'Inventarisierungs-Tab').catch(() => {});
}
async function ensureBulkRuntimeRecovery() {
  if (!bulkRuntimeRecoveryPromise) {
    bulkRuntimeRecoveryPromise = (async () => {
      const recovery = await requireBulkRunGuard().recoverOrphanedRun();
      if (recovery?.recovered) {
        await cleanupRecoveredBulkTabs(recovery.tabIds, 'bulk-runtime-session-lost');
        await logDiagnostic('warning', 'BULK_RUNTIME_SESSION_RECOVERED', {
          runId: recovery.state?.runId || null,
          previousTabs: recovery.tabIds || [],
          stage: recovery.state?.stage || null
        }, { module: 'background', operation: 'bulk-runtime-recovery', context: sessionCorrelationContext(recovery.state || {}) }).catch(() => {});
        broadcastInventoryChanged('bulk-runtime-session-recovered', { runId: recovery.state?.runId || null, status: recovery.state?.status || null });
      }
      return recovery;
    })();
  }
  return bulkRuntimeRecoveryPromise;
}

async function deleteInventoryStorageRecord(inventoryId) { return requireInventoryRepository().deleteWithImages(inventoryId); }

async function moveInventoryToTrash(inventoryId, reason = 'manual', context = {}) { return requireTrashService().moveToTrash(inventoryId, reason, context); }

async function resetTrashRetention(inventoryId) { return requireTrashManagementController().resetTrashRetention(inventoryId); }
async function deleteTrashEntry(inventoryId) { return requireTrashManagementController().deleteTrashEntry(inventoryId); }

async function deleteInventory(inventoryId) {
  const active = await getBulkRunState();
  if (active?.status === "running" || active?.retryAdId) throw new Error("Inventareinträge können während einer laufenden Erfassung oder einer einzelnen Wiederholung nicht gelöscht werden.");
  const id = String(inventoryId || "");
  if (!id) throw new Error("Inventar-ID fehlt.");
  const renewals = await readRenewalSessions().catch(() => ({}));
  const protectedRenewal = Object.values(renewals).find(item => !['cancelled', 'replaced'].includes(String(item?.status || '')) && [String(item?.sourceInventoryId || ''), String(item?.skeletonInventoryId || '')].includes(id));
  if (protectedRenewal) throw new Error('Dieser Inventareintrag gehört zu einem laufenden Renewal-Vorgang und kann derzeit nicht gelöscht werden.');
  const trashed = await moveInventoryToTrash(id, 'manual', { source: 'inventory-delete' });
  await logDiagnostic("info", "INVENTORY_MOVED_TO_TRASH", { inventoryId: id, adId: trashed.adId || null, expiresAt: trashed.trash?.expiresAt || null }).catch(() => {});
  broadcastInventoryChanged('moved-to-trash', { inventoryId: id, adId: trashed.adId || null, expiresAt: trashed.trash?.expiresAt || null });
  return { inventoryId: id, trashed: true, expiresAt: trashed.trash?.expiresAt || null };
}

async function removeReplacementReadyLocal(message) { return requireRemoteDeleteReplacementService().removeReplacementReadyLocal(message); }

async function promoteRenewalCandidateAtomic(session) { return requireRemoteDeleteReplacementService().promoteRenewalCandidateAtomic(session); }

function renewalTargetTabStillOwned(tab, session) { return requireRemoteDeleteReplacementService().renewalTargetTabStillOwned(tab, session); }

function renewalPublishedTargetTabStillOwned(tab, session) { return requireRemoteDeleteReplacementService().renewalPublishedTargetTabStillOwned(tab, session); }

async function closePublishedRenewalTargetTab(session) { return requireRemoteDeleteReplacementService().closePublishedRenewalTargetTab(session); }

async function retirePublishedRenewalTargetTab(session) { return requireRemoteDeleteReplacementService().retirePublishedRenewalTargetTab(session); }

async function closeCompletedRenewalTargetTab(session) { return requireRemoteDeleteReplacementService().closeCompletedRenewalTargetTab(session); }

async function assertMassRenewalManualActionAllowed(message = {}) {
  if (message?.automatic === true || message?.massBatchRetry === true) return;
  const batch = await readMassRenewalBatch().catch(() => null);
  if (batch?.status === 'running') throw new Error('Das Neu-Inserieren läuft noch. Einzelne Wiederholungen sind erst in der Abschlussübersicht möglich.');
}

async function verifyRenewalSourceAbsenceFresh(session, expectedProfile, windowId, attemptState, purpose = 'post-delete') { return requireRemoteDeleteReplacementService().verifyRenewalSourceAbsenceFresh(session, expectedProfile, windowId, attemptState, purpose); }

async function preverifyAndTriggerRenewalSourceDeleteAttempt(session, expectedProfile, windowId, attemptState) { return requireRemoteDeleteReplacementService().preverifyAndTriggerRenewalSourceDeleteAttempt(session, expectedProfile, windowId, attemptState); }

async function finishRenewalReplacement(message, admissionReceipt) { return requireRemoteDeleteReplacementService().finishRenewalReplacement(message, admissionReceipt); }

async function discardRenewalDraft(message) {
  const renewalId = String(message?.renewalId || '');
  if (!renewalId) throw new Error('Renewal-ID fehlt.');
  const renewals = await readRenewalSessions();
  const renewal = renewals[renewalId];
  if (!renewal) throw new Error('Renewal-Entwurf wurde nicht gefunden.');
  if (renewal.newAdId || ['submitted', 'new-id-confirmed', 'reinventorizing', 'verifying', 'verified'].includes(String(renewal.status || '')) || String(renewal.stage || '') === 'publish-submitted') {
    throw new Error('Dieser Renewal-Vorgang wurde bereits veröffentlicht oder zur Veröffentlichung übergeben und kann nicht als lokaler Entwurf verworfen werden.');
  }

  const active = await getBulkRunState();
  if (active?.status === 'running' || active?.retryAdId) throw new Error('Entwürfe können während einer laufenden Erfassung oder einer einzelnen Wiederholung nicht verworfen werden.');

  const skeletonInventoryId = String(renewal.skeletonInventoryId || '');
  const targetTabId = Number(renewal.targetTabId || 0) || null;
  const fillId = String(renewal.fillId || '');

  const fills = await readFillSessions().catch(() => ({}));
  if (fillId && fills[fillId]) {
    delete fills[fillId];
    await writeFillSessions(fills);
  } else {
    let changed = false;
    for (const [id, fill] of Object.entries(fills)) {
      if (String(fill?.renewalId || '') === renewalId) { delete fills[id]; changed = true; }
    }
    if (changed) await writeFillSessions(fills);
  }

  delete renewals[renewalId];
  await writeRenewalSessions(renewals);
  if (skeletonInventoryId) await deleteInventoryStorageRecord(skeletonInventoryId);
  if (targetTabId) await closeRegistryTab(targetTabId, 'renewal-draft-discarded', 'Renewal-Zieltab').catch(() => {});

  await logDiagnostic('info', 'RENEWAL_DRAFT_DISCARDED', {
    renewalId,
    sourceInventoryId: renewal.sourceInventoryId || null,
    sourceAdId: renewal.sourceAdId || null,
    skeletonInventoryId: skeletonInventoryId || null
  }, { module: 'background', operation: 'renewal-discard', context: sessionCorrelationContext(renewal, { renewalId, adId: renewal.sourceAdId || null }) }).catch(() => {});
  broadcastInventoryChanged('renewal-draft-discarded', { inventoryId: skeletonInventoryId || null, renewalId, sourceAdId: renewal.sourceAdId || null });
  return { discarded: true, renewalId, skeletonInventoryId: skeletonInventoryId || null };
}

async function clearInventories(profileId) {
  const retention = (await getTrashRetentionConfiguration()).retentionDays;
  const active = await getBulkRunState();
  if (active?.status === "running" || active?.retryAdId) throw new Error("Die Inventarliste kann während einer laufenden Erfassung oder einer einzelnen Wiederholung nicht geleert werden.");
  const renewals = await readRenewalSessions().catch(() => ({}));
  const records = (await readInventoryRecordsForProfile(profileId)).filter(record => !isTrashRecord(record));
  if (!records.length) return { cleared: true, movedToTrash: 0 };
  const targetIds = new Set(records.map(record => String(record.inventoryId || '')));
  const protectedRenewal = Object.values(renewals).find(item => targetIds.has(String(item?.sourceInventoryId || '')) || targetIds.has(String(item?.skeletonInventoryId || '')));
  if (protectedRenewal) throw new Error('Dieses Profil kann nicht geleert werden, solange darin ein Renewal-Vorgang vorhanden ist. Bitte diesen zuerst abschließen oder verwerfen.');
  const now = new Date();
  const db = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(INVENTORY_STORE, 'readwrite');
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('Inventarliste konnte nicht in den Papierkorb verschoben werden.'));
      const store = tx.objectStore(INVENTORY_STORE);
      for (const record of records) store.put(trashRecordFrom(record, 'inventory-cleared', { source: 'clear-inventory' }, now));
    });
    await logDiagnostic('info', 'INVENTORY_CLEARED_TO_TRASH', { count: records.length, profileId: profileId === UNASSIGNED_PROFILE_ID ? null : (profileId || null), unassigned: profileId === UNASSIGNED_PROFILE_ID, expiresAt: retention === 'infinite' ? null : new Date(now.getTime() + retention * 24 * 60 * 60 * 1000).toISOString() }).catch(() => {});
    broadcastInventoryChanged('cleared-to-trash', { count: records.length });
    return { cleared: true, movedToTrash: records.length };
  } finally { db.close(); }
}

let singleInventoryController = null;
function requireSingleInventoryController() {
  if (!singleInventoryController) {
    singleInventoryController = SingleInventoryController.create({
      getBulkRunState, tabRegistry, chromeTabs: chrome.tabs, singleInventorySourceFromUrl,
      sendTabRequestWithBootstrap, normalizeProfileName, assertSelectedProfileMatchesLiveAccount,
      randomUUID: () => crypto.randomUUID(), logDiagnostic, correlationContext, normalBrowserWindowId,
      createManagedWorkerTab, getInventory, publicUrlForInventoryRecord, extractReadOnlyMetadata,
      readOnlyMetadataTimeoutMs: READONLY_METADATA_TIMEOUT_MS, directPublicUrlForAdId,
      extractSingleInventoryEdit, mergeListingMetadata, saveInventory, closeManagedWorkerTab,
      captureEmergencyResetGeneration, assertEmergencyResetGeneration
    });
  }
  return singleInventoryController;
}

let bulkInventoryController = null;
function requireBulkInventoryController() {
  if (!bulkInventoryController) {
    bulkInventoryController = BulkInventoryController.create({
      getBulkRunState, tabRegistry, tabRegistryApi: TabRegistry, chromeTabs: chrome.tabs, tabRoles: TAB_ROLES, tabStates: TAB_STATES,
      bulkRunOwnerExpectation, normalizeProfileName, ensureProfile, randomUUID: () => crypto.randomUUID(),
      normalizeCorrelationId, normalizeInventoryScope, inventoryScopeApi: InventoryScope, inventoryReconciliationApi: InventoryReconciliation,
      inventoryScopeNewOnly: INVENTORY_SCOPE_NEW_ONLY, readInventoryRecordsForProfile, normalizeRenewalMode,
      registerShadowTab, writeBulkRunState, mutateBulkRunState, logDiagnostic, sessionCorrelationContext,
      closeRegistryTabs, closeRegistryTab, releaseBulkSourceOwnership, broadcastInventoryChanged,
      readRenewalSessions, readFillSessions, readMassRenewalBatch, isTrashRecord, openDatabase, trashRecordFrom,
      getRenewalConfiguration, normalBrowserWindowId, assertPlatformAccessAllowed, createAutomationTab, waitForTabComplete,
      ensureContentConnection, sendTabRequestWithBootstrap, correlationContext, getInventory, deriveListingDateFromEndDate,
      mergeListingMetadata, saveInventory, updateAutomationTab, delay, extractReadOnlyMetadata,
      inventoryStore: INVENTORY_STORE, fastRenewalMode: RENEWAL_MODE_FAST, myAdsProjectsUrl: MY_ADS_PROJECTS_URL,
      platformAccessRestrictionErrorCode: PLATFORM_ACCESS_RESTRICTION_ERROR_CODE,
      bulkWorkerTabCreateMaxAttempts: BULK_WORKER_TAB_CREATE_MAX_ATTEMPTS, bulkWorkerTabCreateRetryMs: BULK_WORKER_TAB_CREATE_RETRY_MS,
      bulkRetryTimeoutMs: BULK_RETRY_TIMEOUT_MS, bulkRetryPollMs: BULK_RETRY_POLL_MS, readOnlyMetadataTimeoutMs: READONLY_METADATA_TIMEOUT_MS,
      freshBulkSourceMaxAttempts: FRESH_BULK_SOURCE_MAX_ATTEMPTS, freshReconciliationSourceMaxAttempts: FRESH_RECONCILIATION_SOURCE_MAX_ATTEMPTS,
      tabLoadTimeoutDefaultMs: TAB_LOAD_TIMEOUT_DEFAULT_MS, URL, setTimeout,
      captureEmergencyResetGeneration, assertEmergencyResetGeneration
    });
  }
  return bulkInventoryController;
}

async function getBulkRunState() {
  await ensureBulkRuntimeRecovery();
  const workerRecovery = await requireBulkRunGuard().recoverExpiredWorkerRun();
  if (workerRecovery?.recovered) {
    await cleanupRecoveredBulkTabs(workerRecovery.tabIds, 'bulk-worker-hard-timeout');
    if (workerRecovery.state?.sourceAutoCreated === true) await closeRegistryTab(workerRecovery.state.sourceTabId, 'bulk-worker-hard-timeout', '„Meine Anzeigen“-Hintergrundtab').catch(() => {});
    else if (workerRecovery.state) await releaseBulkSourceOwnership(workerRecovery.state, 'bulk-worker-hard-timeout').catch(() => {});
    await logDiagnostic('warning', 'BULK_WORKER_HARD_TIMEOUT', {
      runId: workerRecovery.state?.runId || null,
      adId: workerRecovery.state?.currentAdId || null,
      currentItemStartedAt: workerRecovery.state?.currentItemStartedAt || null,
      timeoutMs: BULK_ITEM_HARD_TIMEOUT_MS
    }, { module: 'background', operation: 'bulk-watchdog', context: sessionCorrelationContext(workerRecovery.state || {}, { adId: workerRecovery.state?.currentAdId || null }) }).catch(() => {});
    broadcastInventoryChanged('bulk-worker-timeout', { runId: workerRecovery.state?.runId || null, adId: workerRecovery.state?.currentAdId || null });
  }
  let state = workerRecovery?.state || await requireBulkRunGuard().read();
  if (!state) return null;
  if (state.status === "running" && state.updatedAt && Date.now() - Date.parse(state.updatedAt) > BULK_RUN_MAX_AGE_MS) {
    state = await mutateBulkRunState(current => {
      if (!current || current.status !== 'running') return current;
      current.status = "needs-review";
      current.stage = "stale";
      current.completedAt = new Date().toISOString();
      current.issues = [...new Set([...(current.issues || []), "Die Erfassung wurde wegen zu langer Inaktivität beendet."])];
      return current;
    });
    if (state?.sourceAutoCreated === true) await closeRegistryTab(state.sourceTabId, 'bulk-auto-source-stale', '„Meine Anzeigen“-Hintergrundtab').catch(() => {});
    else if (state) await releaseBulkSourceOwnership(state, 'bulk-stale').catch(() => {});
  }
  return state;
}

async function mutateBulkRunState(mutator) {
  return requireBulkRunGuard().mutate(mutator);
}

async function writeBulkRunState(state) {
  const current = await getBulkRunState().catch(() => null);
  if (current?.emergencyResetAt && String(state?.emergencyResetAt || '') !== String(current.emergencyResetAt)) return current;
  return requireBulkRunGuard().write(state);
}

async function bulkRunWatchdogTick() {
  await ensureBulkRuntimeRecovery();
  const recovery = await requireBulkRunGuard().recoverExpiredWorkerRun();
  if (!recovery?.recovered) return recovery?.state || null;
  await cleanupRecoveredBulkTabs(recovery.tabIds, 'bulk-worker-hard-timeout');
  if (recovery.state?.sourceAutoCreated === true) await closeRegistryTab(recovery.state.sourceTabId, 'bulk-worker-hard-timeout', '„Meine Anzeigen“-Hintergrundtab').catch(() => {});
  else if (recovery.state) await releaseBulkSourceOwnership(recovery.state, 'bulk-worker-hard-timeout').catch(() => {});
  await logDiagnostic('warning', 'BULK_WORKER_HARD_TIMEOUT', {
    runId: recovery.state?.runId || null,
    adId: recovery.state?.currentAdId || null,
    currentItemStartedAt: recovery.state?.currentItemStartedAt || null,
    timeoutMs: BULK_ITEM_HARD_TIMEOUT_MS
  }, { module: 'background', operation: 'bulk-watchdog', context: sessionCorrelationContext(recovery.state || {}, { adId: recovery.state?.currentAdId || null }) }).catch(() => {});
  broadcastInventoryChanged('bulk-worker-timeout', { runId: recovery.state?.runId || null, adId: recovery.state?.currentAdId || null });
  return recovery.state;
}

function normalizedBulkRosterIds(values) { return requireBulkInventoryController().normalizedBulkRosterIds(values); }

function bulkRosterEvidence(pages) { return requireBulkInventoryController().bulkRosterEvidence(pages); }

async function recordBulkRosterPage(message, sender, options = {}) { return requireBulkInventoryController().recordBulkRosterPage(message, sender, options); }

async function beginBulkReconciliation(message, sender) { return requireBulkInventoryController().beginBulkReconciliation(message, sender); }

async function protectedInventoryIdsForReconciliation(profileId) { return requireBulkInventoryController().protectedInventoryIdsForReconciliation(profileId); }

async function moveReconciliationCandidatesToTrash(state, remoteIds) { return requireBulkInventoryController().moveReconciliationCandidatesToTrash(state, remoteIds); }

async function finishBulkReconciliation(message, sender) { return requireBulkInventoryController().finishBulkReconciliation(message, sender); }

function requireBulkSource(state, sender) { return requireBulkInventoryController().requireBulkSource(state, sender); }


async function startBulkInventoryOperation(message = {}) { return requireBulkInventoryController().startBulkInventoryOperation(message); }

let accountSessionController = null;
function requireAccountSessionController() {
  if (!accountSessionController) accountSessionController = AccountSessionController.create({
    AccountProbeService,
    storageSession: chrome.storage.session,
    accountGateDiagnosticStateKey: ACCOUNT_GATE_DIAGNOSTIC_STATE_KEY,
    maxAttempts: ACCOUNT_PROBE_MAX_ATTEMPTS,
    retryDelayMs: ACCOUNT_PROBE_RETRY_DELAY_MS,
    navigationTimeoutMs: ACCOUNT_PROBE_NAVIGATION_TIMEOUT_MS,
    myAdsProjectsUrl: MY_ADS_PROJECTS_URL,
    platformAccessRestrictionErrorCode: PLATFORM_ACCESS_RESTRICTION_ERROR_CODE,
    randomUUID: () => crypto.randomUUID(),
    normalBrowserWindowId,
    createManagedWorkerTab,
    closeManagedWorkerTab,
    updateAutomationTab,
    waitForExpectedTabComplete,
    ensureContentConnection,
    sendTabRequestWithBootstrap,
    normalizeProfileName,
    ensureProfile,
    logDiagnostic,
    delay,
    getProfileState,
    unassignedProfileId: UNASSIGNED_PROFILE_ID
  });
  return accountSessionController;
}
async function probeLiveKleinanzeigenAccount() { return requireAccountSessionController().probeLiveKleinanzeigenAccount(); }
async function assertSelectedProfileMatchesLiveAccount(options = {}) { return requireAccountSessionController().assertSelectedProfileMatchesLiveAccount(options); }

async function bulkSourceWasAutoCreated(sourceTabId) { return requireBulkInventoryController().bulkSourceWasAutoCreated(sourceTabId); }

function scheduleAutoBulkSourceClose(state, reason = 'bulk-auto-source-terminal') { return requireBulkInventoryController().scheduleAutoBulkSourceClose(state, reason); }

async function initBulkRun(message, sender) { return requireBulkInventoryController().initBulkRun(message, sender); }

async function bulkRunForSource(sender) { return requireBulkInventoryController().bulkRunForSource(sender); }

async function updateBulkRun(message, sender) { return requireBulkInventoryController().updateBulkRun(message, sender); }

async function createBulkEditWorkerTabWithRetry(options, state, adId) { return requireBulkInventoryController().createBulkEditWorkerTabWithRetry(options, state, adId); }

async function openBulkWorker(message, sender) { return requireBulkInventoryController().openBulkWorker(message, sender); }

function sendTabRequest(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, response => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      if (!response?.ok) {
        const error = new Error(response?.error || "Worker-Antwort ungültig.");
        if (response?.errorCode) error.code = String(response.errorCode);
        if (response?.errorReasonCode) error.reasonCode = String(response.errorReasonCode);
        if (response?.errorDetails && typeof response.errorDetails === 'object') error.details = { ...response.errorDetails };
        return reject(error);
      }
      resolve(response.result);
    });
  });
}

async function sendTabRequestWithBootstrap(tabId, message) {
  try {
    return await sendTabRequest(tabId, message);
  } catch (error) {
    const text = String(error?.message || error || '');
    if (!/Receiving end does not exist|Could not establish connection|message port closed/i.test(text)) throw error;
    await ensureContentConnection({ tabId });
    return sendTabRequest(tabId, message);
  }
}

const trashTemplatePublishDetectionInFlight = new Set();

let trashTemplatePublishDetectionService = null;
function requireTrashTemplatePublishDetectionService() {
  if (!trashTemplatePublishDetectionService) trashTemplatePublishDetectionService = TrashTemplatePublishDetectionService.create({
    sessionPort: { readFillSessions, writeFillSessions, withTemplateFillMutation },
    tabPort: { tabRegistry, chrome, TAB_ROLES, registerShadowTab, ensureContentConnection, sendTabRequest },
    evidencePort: { publishedAdCandidateFromUrl, URL },
    diagnosticsPort: { logDiagnostic, sessionCorrelationContext, broadcastInventoryChanged },
    statePort: { trashTemplatePublishDetectionInFlight }
  });
  return trashTemplatePublishDetectionService;
}
async function maybeDetectTrashTemplatePublishedAd(tabId, changeInfo = {}, tabHint = null) {
  return requireTrashTemplatePublishDetectionService().maybeDetectTrashTemplatePublishedAd(tabId, changeInfo, tabHint);
}

function isPhase4DeleteTransportInterruption(error) {
  const text = String(error?.message || error || '');
  return /asynchronous response[\s\S]*message channel closed|message channel closed before a response|message port closed|No tab with id/i.test(text);
}

const EXPECTED_CONTROLLED_CLOSE_INTENT_MAX_AGE_MS = 10000;

let contentConnectionManager = null;
function requireContentConnectionManager() {
  if (!contentConnectionManager) {
    contentConnectionManager = ContentConnectionManager.create({
      tabRegistry,
      chromeTabs: chrome.tabs,
      chromeScripting: chrome.scripting,
      isGoneError: error => TabRegistry.isGoneError(error),
      goneState: TAB_STATES.GONE,
      expectedCloseIntentMaxAgeMs: EXPECTED_CONTROLLED_CLOSE_INTENT_MAX_AGE_MS,
      contentScriptFiles: CONTENT_SCRIPT_FILES,
      bootstrapWaitsMs: CONTENT_BOOTSTRAP_WAITS_MS,
      navigationWaitMs: CONTENT_BOOTSTRAP_NAVIGATION_WAIT_MS,
      delay,
      sendTabRequest,
      logDiagnostic,
      assertPlatformAccessAllowed,
      activatePlatformAccessRestriction,
      readPlatformAccessRestriction,
      platformAccessRestrictionError
    });
  }
  return contentConnectionManager;
}
function isExpectedControlledTabCloseReason(reason) {
  const value = String(reason || '');
  return /^(?:renewal-target-(?:published|completed)|renewal-draft-discarded|renewal-phase1-retry|renewal-resume-cleanup|managed-worker-closed|bulk-worker-(?:replaced|saved|closed)|bulk-retry-worker-(?:finished|failed)|inventory-refresh-worker-(?:finished|failed)|bulk-run-failed|bulk-source-gone-cleanup|bulk-auto-source-(?:stale|prepare-failed|preflight-failed|finished|failed|terminal)|workflow-close)$/.test(value);
}

async function expectedControlledTabCloseEntry(tabId) {
  const id = Number(tabId || 0);
  if (!id) return null;
  const entry = await tabRegistry.get(id).catch(() => null);
  if (!entry) return null;
  const goneReason = entry.lifecycleState === TAB_STATES.GONE ? String(entry.goneReason || '') : '';
  const closeIntentAt = Date.parse(String(entry.closeIntentAt || ''));
  const closeIntentAgeMs = Number.isFinite(closeIntentAt) ? Math.max(0, Date.now() - closeIntentAt) : Number.POSITIVE_INFINITY;
  const closeIntentReason = closeIntentAgeMs <= EXPECTED_CONTROLLED_CLOSE_INTENT_MAX_AGE_MS ? String(entry.closeIntentReason || '') : '';
  const expectedReason = isExpectedControlledTabCloseReason(goneReason) ? goneReason : (isExpectedControlledTabCloseReason(closeIntentReason) ? closeIntentReason : '');
  if (!expectedReason) return null;
  const owner = entry.owner && typeof entry.owner === 'object' ? entry.owner : {};
  const correlated = entry.managed === true || Object.values(owner).some(value => String(value || '').trim());
  return correlated ? { ...entry, expectedCloseReason: expectedReason } : null;
}

function expectedControlledTabCloseError(tabId, entry) {
  const id = Number(tabId || 0) || null;
  const reason = String(entry?.expectedCloseReason || entry?.goneReason || entry?.closeIntentReason || 'workflow-close');
  const error = new Error(`KR_TAB_EXPECTED_CLOSED: Kleinanzeigen-Tab ${id || ''} wurde vom Workflow planmäßig geschlossen.`.trim());
  error.code = 'KR_TAB_EXPECTED_CLOSED'; error.tabId = id; error.goneReason = reason; return error;
}

async function getContentConnectionTabOrThrow(tabId) { return requireContentConnectionManager().getContentConnectionTabOrThrow(tabId); }

function kleinanzeigenTabMeta(tab) { return requireContentConnectionManager().kleinanzeigenTabMeta(tab); }

function validKleinanzeigenTab(tab) {
  try { const url = new URL(tab?.url || ''); return url.protocol === 'https:' && /(^|\.)kleinanzeigen\.de$/i.test(url.hostname); } catch { return false; }
}

function contentBootstrapNeedsNavigationWait(tab) { return String(tab?.status || '') === 'loading'; }

async function waitForContentBootstrapNavigation(tabId, initialTab = null) { return requireContentConnectionManager().waitForContentBootstrapNavigation(tabId, initialTab); }

async function rethrowExpectedContentBootstrapCloseIfNeeded(tabId, started, phase) {
  const entry = await expectedControlledTabCloseEntry(tabId);
  if (!entry) return false;
  const goneReason = String(entry.expectedCloseReason || entry.goneReason || entry.closeIntentReason || 'workflow-close');
  await logDiagnostic('info', 'CONTENT_SCRIPT_BOOTSTRAP_EXPECTED_TAB_CLOSE', {
    tabId, phase: String(phase || 'bootstrap'), durationMs: Math.max(0, Date.now() - Number(started || Date.now())), goneReason, role: entry.role || null
  }, { module: 'background', operation: 'content-bootstrap', context: { tabId, ...(entry.owner || {}) } }).catch(() => {});
  throw expectedControlledTabCloseError(tabId, entry);
}

async function ensureContentConnection(message) { return requireContentConnectionManager().ensureContentConnection(message); }

async function normalBrowserWindowId() {
  const windows = await chrome.windows.getAll({ windowTypes: ['normal'] }).catch(() => []);
  const focused = windows.find(item => item.focused) || windows[0];
  return focused?.id ?? null;
}

let manualListingNavigationController = null;
function requireManualListingNavigationController() {
  if (!manualListingNavigationController) manualListingNavigationController = ManualListingNavigationController.create({
    navigationPort: { normalBrowserWindowId, createAutomationTab, waitForTabComplete, chrome },
    evidencePort: { getInventory, normalizeKnownPublicAdUrl, publicUrlForInventoryRecord, directPublicUrlForAdId },
    diagnosticsPort: { logDiagnostic }
  });
  return manualListingNavigationController;
}
async function openEditAd(message) {
  return requireManualListingNavigationController().openEditAd(message);
}

let publicListingEvidenceService = null;
function requirePublicListingEvidenceService() {
  if (!publicListingEvidenceService) {
    publicListingEvidenceService = PublicListingEvidenceService.create({
      URL, chromeTabs: chrome.tabs, delay, ensureContentConnection, sendTabRequestWithBootstrap,
      readOnlyMetadataTimeoutMs: READONLY_METADATA_TIMEOUT_MS,
      normalizeProfileName, createAutomationTab, waitForTabComplete, closeRegistryTabs,
      MY_ADS_PROJECTS_URL, TAB_LOAD_TIMEOUT_RENEWAL_MS
    });
  }
  return publicListingEvidenceService;
}

function normalizeKnownPublicAdUrl(rawUrl, expectedAdId) { return requirePublicListingEvidenceService().normalizeKnownPublicAdUrl(rawUrl, expectedAdId); }

async function openReadOnlyAd(message) {
  return requireManualListingNavigationController().openReadOnlyAd(message);
}

let tabLoadCoordinator = null;
function requireTabLoadCoordinator() {
  if (tabLoadCoordinator) return tabLoadCoordinator;
  if (!TabLoadCoordinator?.create) throw new Error('tab-load-coordinator.js must load before tab readiness is used');
  tabLoadCoordinator = TabLoadCoordinator.create({
    safetyPollMs: TAB_LOAD_SAFETY_POLL_MS,
    assertPlatformAccessAllowed,
    getTabOrThrow: (tabId, { label } = {}) => tabRegistry.getTabOrThrow(tabId, chrome.tabs, { label }),
    getTab: tabId => chrome.tabs.get(tabId),
    logDiagnostic,
    tabMeta: kleinanzeigenTabMeta,
    assessNavigation: (tab, expectedUrl) => ManagedNavigation.assess(tab, expectedUrl),
    readyState: ManagedNavigation.STATES.READY,
    offTargetState: ManagedNavigation.STATES.OFF_TARGET
  });
  return tabLoadCoordinator;
}

// Tab-readiness facade: background.js retains orchestration call sites while
// waiter/version state and event-driven navigation coordination live in tab-load-coordinator.js.
function tabLoadSignalVersion(tabId) { return requireTabLoadCoordinator().signalVersion(tabId); }
function notifyTabLoadWaiters(tabId, signal = {}) { return requireTabLoadCoordinator().notify(tabId, signal); }
function notifyAllTabLoadWaiters(signal = {}) { return requireTabLoadCoordinator().notifyAll(signal); }
function waitForTabLoadSignal(tabId, afterVersion, timeoutMs) { return requireTabLoadCoordinator().waitForSignal(tabId, afterVersion, timeoutMs); }
async function waitForTabComplete(tabId, timeoutOrOptions = TAB_LOAD_TIMEOUT_DEFAULT_MS) {
  return requireTabLoadCoordinator().waitForComplete(tabId, timeoutOrOptions);
}
async function waitForExpectedTabComplete(tabId, expectedUrl, timeoutOrOptions = TAB_LOAD_TIMEOUT_DEFAULT_MS) {
  return requireTabLoadCoordinator().waitForExpectedComplete(tabId, expectedUrl, timeoutOrOptions);
}

function slugifyListingTitle(value) { return requirePublicListingEvidenceService().slugifyListingTitle(value); }

function publicUrlForInventoryRecord(record) { return requirePublicListingEvidenceService().publicUrlForInventoryRecord(record); }

function directPublicUrlForAdId(adId) { return requirePublicListingEvidenceService().directPublicUrlForAdId(adId); }

function publicAvailabilityPending(record) { return requirePublicListingEvidenceService().publicAvailabilityPending(record); }

function publicAvailabilitySnapshot(options = {}) { return requirePublicListingEvidenceService().publicAvailabilitySnapshot(options); }

let listingUrlEvidenceService = null;
function requireListingUrlEvidenceService() {
  if (!listingUrlEvidenceService) listingUrlEvidenceService = ListingUrlEvidenceService.create({ URL });
  return listingUrlEvidenceService;
}
function singleInventorySourceFromUrl(rawUrl) {
  return requireListingUrlEvidenceService().singleInventorySourceFromUrl(rawUrl);
}

async function extractSingleInventoryEdit(tabId, adId, correlation = {}, { ownedWorker = false } = {}) {
  const id = Number(tabId || 0);
  if (!id || !/^\d+$/.test(String(adId || ''))) throw new Error('Bearbeiten-Quelle für die Einzelinventur ist ungültig.');
  const deadline = Date.now() + BULK_RETRY_TIMEOUT_MS;
  let lastReason = '';
  while (Date.now() < deadline) {
    try {
      const tab = await tabRegistry.getTabOrThrow(id, chrome.tabs, { label: ownedWorker ? 'Einzelinventur-Bearbeiten-Worker' : 'Geöffnete Bearbeiten-Ansicht' });
      const navigation = classifyBulkEditWorkerNavigation(tab, adId);
      if (navigation.state === 'terminal') throw new Error(navigation.reason);
      if (navigation.state !== 'ready') {
        lastReason = navigation.reason || 'Bearbeiten-Ansicht wird noch geladen.';
      } else {
        await ensureContentConnection({ tabId: id });
        const extracted = await sendTabRequestWithBootstrap(id, { type: 'EXTRACT_CURRENT_AD' });
        if (String(extracted?.adId || '') === String(adId)) return extracted;
        lastReason = `Bearbeiten-Ansicht ${extracted?.adId || 'unbekannt'} entspricht nicht ${adId}.`;
      }
    } catch (error) {
      if (TabRegistry.isGoneError(error)) throw error;
      lastReason = String(error?.message || error).slice(0, 500);
    }
    await delay(BULK_RETRY_POLL_MS);
  }
  throw new Error(lastReason || 'Die Bearbeiten-Ansicht wurde nicht rechtzeitig vollständig inventarisierbar.');
}

function detectPublishedAdFromKnownUrl(rawUrl, sourceAdId = '') {
  return requireListingUrlEvidenceService().detectPublishedAdFromKnownUrl(rawUrl, sourceAdId);
}

async function detectPublishedAdForFill(tabId, sourceAdId) {
  const tab = await chrome.tabs.get(Number(tabId)).catch(() => null);
  const direct = detectPublishedAdFromKnownUrl(tab?.url || '', sourceAdId);
  if (direct?.adId) return direct;
  await ensureContentConnection({ tabId: Number(tabId) });
  const detected = await sendTabRequestWithBootstrap(Number(tabId), { type: 'DETECT_PUBLISHED_AD', sourceAdId });
  return detected?.adId ? { ...detected, detectionSource: detected.detectionSource || 'content' } : null;
}

let renewalPublicEvidenceCoordinator = null;
function requireRenewalPublicEvidenceCoordinator() {
  if (!renewalPublicEvidenceCoordinator) renewalPublicEvidenceCoordinator = RenewalPublicEvidenceCoordinator.create({
    tabPort: {
      assertPlatformAccessAllowed, tabLoadSignalVersion, waitForTabLoadSignal, kleinanzeigenTabMeta, normalBrowserWindowId, createAutomationTab, registerManagedWorkerTab, updateAutomationTab, closeManagedWorkerTab, waitForExpectedTabComplete, ensureContentConnection, sendTabRequestWithBootstrap, tabRegistry, chrome, ManagedNavigation
    },
    diagnosticsPort: { logDiagnostic, correlationContext, sessionCorrelationContext },
    policyPort: { renewalAttemptState, isNonRetryableRenewalSafetyError, normalizeProfileName },
    evidencePort: { extractReadOnlyMetadata, normalizeKnownPublicAdUrl, directPublicUrlForAdId },
    configPort: { TAB_LOAD_TIMEOUT_RENEWAL_MS, TAB_LOAD_SAFETY_POLL_MS, RENEWAL_PUBLIC_READONLY_READINESS_TIMEOUT_MS, READONLY_METADATA_TIMEOUT_MS, RENEWAL_DIRECT_READONLY_TIMEOUT_MS, MY_ADS_PROJECTS_URL }
  });
  return renewalPublicEvidenceCoordinator;
}
async function probeFreshRenewalPublicUrl(url, expectedAdId, publicUrlVariant, timeoutMs = READONLY_METADATA_TIMEOUT_MS, correlation = {}) {
  return requireRenewalPublicEvidenceCoordinator().probeFreshRenewalPublicUrl(url, expectedAdId, publicUrlVariant, timeoutMs, correlation);
}
function renewalEvidenceFailureClass(results = []) {
  return requireRenewalPublicEvidenceCoordinator().renewalEvidenceFailureClass(results);
}
async function resolveRenewalPublicEvidence(newAdId, expectedProfileName, correlation = {}) {
  return requireRenewalPublicEvidenceCoordinator().resolveRenewalPublicEvidence(newAdId, expectedProfileName, correlation);
}

async function extractReadOnlyMetadata(tabId, expectedAdId, timeoutMs = READONLY_METADATA_TIMEOUT_MS, options = {}) { return requirePublicListingEvidenceService().extractReadOnlyMetadata(tabId, expectedAdId, timeoutMs, options); }

function normalizedCalendarParts(isoValue = '', displayValue = '') { return requirePublicListingEvidenceService().normalizedCalendarParts(isoValue, displayValue); }

function deriveListingDateFromEndDate(endDateIso = '', endDateDisplay = '', days = 60) { return requirePublicListingEvidenceService().deriveListingDateFromEndDate(endDateIso, endDateDisplay, days); }

function mergeListingMetadata(extracted, existingMeta = {}, readOnlyResult = null, fallback = {}) { return requirePublicListingEvidenceService().mergeListingMetadata(extracted, existingMeta, readOnlyResult, fallback); }

async function captureSingleInventory(message) { return requireSingleInventoryController().captureSingleInventory(message); }

let inventoryRefreshService = null;
function requireInventoryRefreshService() {
  if (!inventoryRefreshService) inventoryRefreshService = InventoryRefreshService.create({
    getInventory,
    assertSelectedProfileMatchesLiveAccount,
    publicAvailabilityPending,
    getBulkRunState,
    normalizeKnownPublicAdUrl,
    publicUrlForInventoryRecord,
    directPublicUrlForAdId,
    logDiagnostic,
    probeFreshRenewalPublicUrl,
    mergeListingMetadata,
    publicAvailabilitySnapshot,
    putInventoryRecordOnly,
    broadcastInventoryChanged,
    renewalEvidenceFailureClass,
    readRenewalSessions,
    normalBrowserWindowId,
    createAutomationTab,
    extractReadOnlyMetadata,
    waitForTabComplete,
    ensureContentConnection,
    sendTabRequestWithBootstrap,
    delay,
    requirePublicListingEvidenceService,
    saveInventory,
    normalizeRenewalMode,
    compareRenewalRecords,
    renewalOutcomeForComparison,
    persistRenewalSession,
    sessionCorrelationContext,
    closeRegistryTabs,
    RENEWAL_DIRECT_READONLY_TIMEOUT_MS,
    READONLY_METADATA_TIMEOUT_MS,
    TAB_LOAD_TIMEOUT_RENEWAL_MS,
    BULK_RETRY_TIMEOUT_MS,
    BULK_RETRY_POLL_MS,
    RENEWAL_MODE_SAFE
  });
  return inventoryRefreshService;
}
async function checkInventoryOnlineStatus(message) {
  return requireInventoryRefreshService().checkInventoryOnlineStatus(message);
}
async function refreshInventoryRecord(message) {
  return requireInventoryRefreshService().refreshInventoryRecord(message);
}

function classifyBulkEditWorkerNavigation(tab, expectedAdId) { return requireBulkInventoryController().classifyBulkEditWorkerNavigation(tab, expectedAdId); }

async function resolveBulkWorkerLifecycle(state, workerTabId, expectedAdId) { return requireBulkInventoryController().resolveBulkWorkerLifecycle(state, workerTabId, expectedAdId); }

async function extractSaveBulkWorker(message, sender) { return requireBulkInventoryController().extractSaveBulkWorker(message, sender); }

async function closeBulkWorker(message, sender) { return requireBulkInventoryController().closeBulkWorker(message, sender); }

async function recordBulkExistingSkip(message, sender) { return requireBulkInventoryController().recordBulkExistingSkip(message, sender); }

async function recordBulkResult(message, sender) { return requireBulkInventoryController().recordBulkResult(message, sender); }

async function requestBulkInventoryStopAfterCurrent(message) { return requireBulkInventoryController().requestBulkInventoryStopAfterCurrent(message); }

async function finishBulkRunControlledStop(message, sender) { return requireBulkInventoryController().finishBulkRunControlledStop(message, sender); }

function scheduleBulkSourceTabClose(tabId, reason = 'bulk-source-replaced') { return requireBulkInventoryController().scheduleBulkSourceTabClose(tabId, reason); }

async function prepareFreshBulkReconciliationSource(state, sender) { return requireBulkInventoryController().prepareFreshBulkReconciliationSource(state, sender); }

async function finishBulkRun(message, sender) { return requireBulkInventoryController().finishBulkRun(message, sender); }

async function failBulkRun(message, sender) { return requireBulkInventoryController().failBulkRun(message, sender); }

async function retryBulkFailure(message) { return requireBulkInventoryController().retryBulkFailure(message); }

let massRenewalController = null;
function requireMassRenewalController() {
  if (!massRenewalController) {
    massRenewalController = MassRenewalController.create({
      storageLocal: chrome.storage.local,
      batchKey: MASS_RENEWAL_BATCH_KEY,
      batchMaxAgeMs: MASS_RENEWAL_BATCH_MAX_AGE_MS,
      progressFlushMs: MASS_RENEWAL_PROGRESS_FLUSH_MS,
      normalizeRenewalMode,
      normalizeRenewalPhaseAttempts,
      broadcastInventoryChanged,
      logDiagnostic,
      sessionCorrelationContext,
      reconcileMassRenewalBatchSession: (...args) => reconcileMassRenewalBatchSession(...args)
    });
  }
  return massRenewalController;
}
function massRenewalTerminalOutcome(session) { return requireMassRenewalController().massRenewalTerminalOutcome(session); }
async function readMassRenewalBatch() { return requireMassRenewalController().readMassRenewalBatch(); }
async function writeMassRenewalBatch(batch) {
  const current = await requireMassRenewalController().readMassRenewalBatch().catch(() => null);
  if (current?.emergencyResetAt && String(batch?.emergencyResetAt || '') !== String(current.emergencyResetAt)) return current;
  return requireMassRenewalController().writeMassRenewalBatch(batch);
}
function massRenewalBatchCounts(batch) { return requireMassRenewalController().massRenewalBatchCounts(batch); }
function massRenewalPublicSnapshot(batch) { return requireMassRenewalController().massRenewalPublicSnapshot(batch); }
function dropMassRenewalProgress(session) { return requireMassRenewalController().dropMassRenewalProgress(session); }
async function flushMassRenewalProgress() { return requireMassRenewalController().flushMassRenewalProgress(); }
function queueMassRenewalProgress(session) { return requireMassRenewalController().queueMassRenewalProgress(session); }
function withMassRenewalMutation(task) { return requireMassRenewalController().withMassRenewalMutation(task); }
async function mutateMassRenewalBatch(batchId, mutator) { return requireMassRenewalController().mutateMassRenewalBatch(batchId, mutator); }
function touchMassRenewalItemProgress(item, now) { return requireMassRenewalController().touchMassRenewalItemProgress(item, now); }
function applyMassRenewalStopState(batch) { return requireMassRenewalController().applyMassRenewalStopState(batch); }
function applyMassRenewalFinalState(batch) { return requireMassRenewalController().applyMassRenewalFinalState(batch); }
async function stopMassRenewalBatchBeforeNext(batchId) { return requireMassRenewalController().stopMassRenewalBatchBeforeNext(batchId); }
async function finalizeMassRenewalBatchIfDone(batchId) { return requireMassRenewalController().finalizeMassRenewalBatchIfDone(batchId); }

let massRenewalWorkflowController = null;
function requireMassRenewalWorkflowController() {
  if (!massRenewalWorkflowController) {
    massRenewalWorkflowController = MassRenewalWorkflowController.create({
      readRenewalSessions, writeRenewalSessions,
      mutateMassRenewalBatch, applyMassRenewalStopState, applyMassRenewalFinalState,
      touchMassRenewalItemProgress, massRenewalTerminalOutcome, massRenewalPublicSnapshot,
      readMassRenewalBatch, writeMassRenewalBatch, withMassRenewalMutation, dropMassRenewalProgress,
      logDiagnostic, sessionCorrelationContext, normalizeRenewalPhaseAttempts,
      startTemplateFillUnlocked, withInsertionStartGate, assertInsertionStartAvailable,
      getProfileState, assertSelectedProfileMatchesLiveAccount, getInventory, isTrashRecord,
      assertTemplateSourceReady, getRenewalConfiguration, normalizeRenewalMode,
      finishRenewalReplacement, retryRenewalVerification, discardRenewalDraft,
      publicAvailabilityPending, readFillSessions, classifyKleinanzeigenInsertionErrorUrl,
      terminalizeTemplateFillOnPlatformError, terminalizeTemplateFillForWatchdog, persistRenewalSession,
      cryptoApi: globalThis.crypto, chromeApi: chrome, queueMicrotaskFn: globalThis.queueMicrotask,
      withAutonomousAdmission: (kind, task) => withAutonomousAdmission(kind, task),
      setTimeoutFn: globalThis.setTimeout, clearTimeoutFn: globalThis.clearTimeout,
      MASS_RENEWAL_MAX_ITEMS, MASS_RENEWAL_WATCHDOG_STALE_MS, MASS_RENEWAL_WATCHDOG_TICK_MS,
      UNASSIGNED_PROFILE_ID
    });
  }
  return massRenewalWorkflowController;
}
function findMassRenewalSessionForItem(batchId, itemIndex) { return requireMassRenewalWorkflowController().findMassRenewalSessionForItem(batchId, itemIndex); }
async function startNextMassRenewalItem(batchId) { return requireMassRenewalWorkflowController().startNextMassRenewalItem(batchId); }
async function reconcileMassRenewalBatchSession(session, options = {}) { return requireMassRenewalWorkflowController().reconcileMassRenewalBatchSession(session, options); }
async function markMassRenewalItemSucceeded(session, result = {}) { return requireMassRenewalWorkflowController().markMassRenewalItemSucceeded(session, result); }
async function startMassRenewalBatch(message) { return requireMassRenewalWorkflowController().startMassRenewalBatch(message); }
async function requestMassRenewalStopAfterCurrent(message) { return requireMassRenewalWorkflowController().requestMassRenewalStopAfterCurrent(message); }
async function normalizeMassRenewalBatchTopLevelStatus(batchId = '', trigger = 'status-query') { return requireMassRenewalWorkflowController().normalizeMassRenewalBatchTopLevelStatus(batchId, trigger); }
async function getMassRenewalBatchStatus() { return requireMassRenewalWorkflowController().getMassRenewalBatchStatus(); }
async function retryMassRenewalItem(message) { return requireMassRenewalWorkflowController().retryMassRenewalItem(message); }
async function resumeMassRenewalBatch() { return requireMassRenewalWorkflowController().resumeMassRenewalBatch(); }
function latestMassRenewalProgressMs(item, renewal, fill) { return requireMassRenewalWorkflowController().latestMassRenewalProgressMs(item, renewal, fill); }
function armMassRenewalWatchdog() { return requireMassRenewalWorkflowController().armMassRenewalWatchdog(); }
async function runMassRenewalWatchdog(options = {}) { return requireMassRenewalWorkflowController().runMassRenewalWatchdog(options); }
async function massRenewalWatchdogTick(message, sender) { return requireMassRenewalWorkflowController().massRenewalWatchdogTick(message, sender); }
function resetMassRenewalWorkflowRuntimeState() { return requireMassRenewalWorkflowController().resetRuntimeState(); }


async function readRenewalSessions() { return requireRenewalStateRepository().readRenewalSessions(); }
async function writeRenewalSessions(sessions) { return requireRenewalStateRepository().writeRenewalSessions(sessions); }

async function readArchiveInsertionSessions() { return requireArchiveInsertionService().readArchiveInsertionSessions(); }
async function writeArchiveInsertionSessions(sessions) { return requireArchiveInsertionService().writeArchiveInsertionSessions(sessions); }
function archiveInsertionPublicSnapshot(session) { return requireArchiveInsertionService().archiveInsertionPublicSnapshot(session); }
function broadcastArchiveInsertionState(session, reason = 'session-updated') { return requireArchiveInsertionService().broadcastArchiveInsertionState(session, reason); }
async function persistArchiveInsertionSession(session, options = {}) { return requireArchiveInsertionService().persistArchiveInsertionSession(session, options); }
async function getArchiveInsertionStatus(message) { return requireArchiveInsertionService().getArchiveInsertionStatus(message); }

let archiveInsertionController = null;
function requireArchiveInsertionController() {
  if (!archiveInsertionController) {
    archiveInsertionController = ArchiveInsertionController.create({
      readArchiveInsertionSessions, writeArchiveInsertionSessions, archiveInsertionPublicSnapshot, persistArchiveInsertionSession, archiveInsertionMeta,
      getInventory, isTrashRecord, getInventoryImage, deleteImagesByInventoryId, assertTemplateSourceReady,
      inventoryImageSetExplicitlyEmpty, compareRenewalRecords, normalizedScalar, normalizedComparableBoolean,
      normalizeProfileName, normalizeRenewalMode, ensureProfile, saveInventory, openDatabase,
      normalBrowserWindowId, createManagedWorkerTab, closeManagedWorkerTab, waitForTabComplete,
      ensureContentConnection, sendTabRequestWithBootstrap, updateAutomationTab, reloadAutomationTab,
      createAutomationTab, registerShadowTab, closePublishedRenewalTargetTab,
      assertSelectedProfileMatchesLiveAccount, getRenewalConfiguration, withInsertionStartGate, assertInsertionStartAvailable,
      readFillSessions, writeFillSessions, detectPublishedAdForFill,
      withAutonomousAdmission, resolvePublishIntent: resolveManagedPublishIntent,
      correlationContext, sessionCorrelationContext, delay, logDiagnostic, setAppNotice, broadcastInventoryChanged,
      cryptoApi: globalThis.crypto, chromeApi: chrome,
      MY_ADS_PROJECTS_URL, TAB_LOAD_TIMEOUT_RENEWAL_MS, BULK_RETRY_TIMEOUT_MS, BULK_RETRY_POLL_MS,
      RENEWAL_MODE_FAST, TEMPLATE_TARGET_URL, TAB_ROLES, INVENTORY_STORE, IMAGE_STORE
    });
  }
  return archiveInsertionController;
}
async function resumePendingArchiveInsertions() { return requireArchiveInsertionController().resumePendingArchiveInsertions(); }
async function runArchiveInsertionPostPublish(archiveInsertionId) { return requireArchiveInsertionController().runArchiveInsertionPostPublish(archiveInsertionId); }
async function confirmPublishedArchiveInsertion(fill, detected) { return requireArchiveInsertionController().confirmPublishedArchiveInsertion(fill, detected); }
async function startArchiveInsertion(message) { return requireArchiveInsertionController().startArchiveInsertion(message); }

async function putInventoryRecordOnly(record) { return requireInventoryRepository().put(record); }

function renewalInsertionMeta(session) { return requireRenewalStateRepository().renewalInsertionMeta(session); }
function renewalPublicSnapshot(session) { return requireRenewalStateRepository().renewalPublicSnapshot(session); }


let renewalWorkflowController = null;
let phase4Journal = null;
function requirePhase4UncertaintyJournal() {
  if (!phase4Journal) {
    phase4Journal = Phase4UncertaintyJournal.create({
      storageLocal: chrome.storage.local, clock: () => Date.now(),
      newToken: () => crypto.randomUUID(), workerInstanceId: ownerWorkerInstanceId,
      verifyRemoteOutcome: receipt => requireRemoteDeleteReplacementService().verifyPhase4RemoteOutcomeFresh(receipt),
      lockName: AtomicMV3Admission.LOCK_NAME,
      lockManager: globalThis.navigator?.locks
    });
  }
  return phase4Journal;
}
let autoPublishIntentJournal = null;
function requireAutoPublishIntentJournal() {
  if (!autoPublishIntentJournal) {
    autoPublishIntentJournal = AutoPublishIntentJournal.create({
      storageLocal: chrome.storage.local, clock: () => Date.now(),
      newToken: () => crypto.randomUUID(), workerInstanceId: ownerWorkerInstanceId,
      lockName: AtomicMV3Admission.LOCK_NAME,
      lockManager: globalThis.navigator?.locks,
      verifyRemoteOutcome: (intent, newAdId) => verifyAutoPublishRemoteOutcomeFresh(intent, newAdId)
    });
  }
  return autoPublishIntentJournal;
}
// A caller-supplied new-ID redirect is only a candidate. Read-only My Ads
// verification in an independent managed tab is the sole outcome authority.
let publishIntentAuthorizationService = null;
function requirePublishIntentAuthorizationService() {
  if (!publishIntentAuthorizationService) publishIntentAuthorizationService = PublishIntentAuthorizationService.create({
    sessionPort: { readArchiveInsertionSessions, readRenewalSessions, readFillSessions },
    accountPort: { assertSelectedProfileMatchesLiveAccount, normalizeProfileName },
    tabPort: { createManagedWorkerTab, waitForTabComplete, ensureContentConnection, sendTabRequestWithBootstrap, closeManagedWorkerTab },
    journalPort: { requireAutoPublishIntentJournal },
    configPort: { MY_ADS_PROJECTS_URL, TAB_LOAD_TIMEOUT_PHASE4_MS, URL }
  });
  return publishIntentAuthorizationService;
}
async function verifyAutoPublishRemoteOutcomeFresh(intent, newAdId) {
  return requirePublishIntentAuthorizationService().verifyAutoPublishRemoteOutcomeFresh(intent, newAdId);
}
async function resolveManagedPublishIntent(fill, detected) {
  return requirePublishIntentAuthorizationService().resolveManagedPublishIntent(fill, detected);
}
async function authorizeAutomaticPublish(message, sender, admissionReceipt) {
  return requirePublishIntentAuthorizationService().authorizeAutomaticPublish(message, sender, admissionReceipt);
}
function requireRenewalWorkflowController() {
  if (!renewalWorkflowController) {
    renewalWorkflowController = RenewalWorkflowController.create({
      assertMassRenewalManualActionAllowed, broadcastInventoryChanged, closeManagedWorkerTab, closeRegistryTab,
      compareRenewalRecords, correlationContext, createManagedWorkerTab, delay, detectPublishedAdForFill,
      dropMassRenewalProgress, ensureContentConnection, evaluateCheckoutRecoveryProof, finishRenewalReplacement,
      withAutonomousAdmission, resolvePublishIntent: resolveManagedPublishIntent,
      flushDiagnosticBuffer, getInventory, isCheckoutAbortedRecoveryCandidate, isNonRetryableRenewalSafetyError,
      isSafeLegacyManualEmergencyReset, logDiagnostic, logRenewalPhaseAttemptFailed, logRenewalPhaseAttemptStarted,
      massRenewalBatchCounts, massRenewalTerminalOutcome, mergeListingMetadata, mutateMassRenewalBatch,
      normalBrowserWindowId, normalizeKnownPublicAdUrl, normalizeProfileName, normalizeRenewalMode, normalizeRenewalPhaseAttempts,
      persistArchiveInsertionSession, publicAvailabilitySnapshot, putInventoryRecordOnly, queueMassRenewalProgress,
      readArchiveInsertionSessions, readDiagnostics, readFillSessions, readInventoryRecordsForProfile, readProfiles,
      readRenewalSessions, reconcileMassRenewalBatchSession, renewalAttemptState, renewalComparisonWaitsOnlyForOnline,
      renewalInsertionMeta, renewalMaxPhaseAttempts, renewalAttemptDetails, renewalOutcomeForComparison, renewalPhaseAttemptAvailable,
      renewalPhaseRetryDelayMs, renewalPublicSnapshot, resetRenewalPhaseAttempts, resolveRenewalPublicEvidence,
      retirePublishedRenewalTargetTab, saveInventory, sendTabRequestWithBootstrap, sessionCorrelationContext,
      touchMassRenewalItemProgress, waitForTabComplete, writeFillSessions, writeRenewalSessions,
      BULK_RETRY_POLL_MS, BULK_RETRY_TIMEOUT_MS, MY_ADS_PROJECTS_URL, RENEWAL_MODE_FAST, RENEWAL_MODE_SAFE,
      RENEWAL_PHASE_ATTEMPTS_DEFAULT, TAB_LOAD_TIMEOUT_PHASE4_MS, TAB_LOAD_TIMEOUT_RENEWAL_MS
    });
  }
  return renewalWorkflowController;
}

async function createRenewalSkeleton(source, renewalId, options = {}) { return requireRenewalWorkflowController().createRenewalSkeleton(source, renewalId, options); }
async function updateRenewalSkeleton(session, patch = {}) { return requireRenewalWorkflowController().updateRenewalSkeleton(session, patch); }
async function sendRenewalFeedback(session, title, text, issues = []) { return requireRenewalWorkflowController().sendRenewalFeedback(session, title, text, issues); }
async function persistRenewalSession(session) { return requireRenewalWorkflowController().persistRenewalSession(session); }
function scheduleAutomaticRenewalReplacement(renewalId, trigger = 'verification-match') { return requireRenewalWorkflowController().scheduleAutomaticRenewalReplacement(renewalId, trigger); }
async function runFastRenewalVerification(renewalId) { return requireRenewalWorkflowController().runFastRenewalVerification(renewalId); }
async function runRenewalReinventory(renewalId) { return requireRenewalWorkflowController().runRenewalReinventory(renewalId); }
async function retryRenewalVerification(message) { return requireRenewalWorkflowController().retryRenewalVerification(message); }
async function markRenewalPublishClicked(message, sender) { return requireRenewalWorkflowController().markRenewalPublishClicked(message, sender); }
async function confirmPublishedRenewal(fill, detected) { return requireRenewalWorkflowController().confirmPublishedRenewal(fill, detected); }
async function checkoutRecoveryEvidenceForRenewal(session) { return requireRenewalWorkflowController().checkoutRecoveryEvidenceForRenewal(session); }
async function checkoutRecoveryBaselineForRenewal(session) { return requireRenewalWorkflowController().checkoutRecoveryBaselineForRenewal(session); }
async function verifyAbortedPaidCheckoutNoPublication(session, trigger = 'recovery') { return requireRenewalWorkflowController().verifyAbortedPaidCheckoutNoPublication(session, trigger); }
async function finalizeVerifiedCheckoutAbort(session, proof, trigger = 'recovery') { return requireRenewalWorkflowController().finalizeVerifiedCheckoutAbort(session, proof, trigger); }
async function tryRecoverAbortedPaidCheckout(session, trigger = 'recovery') { return requireRenewalWorkflowController().tryRecoverAbortedPaidCheckout(session, trigger); }
async function resumePendingRenewals() { return requireRenewalWorkflowController().resumePendingRenewals(); }






let renewalVerificationService = null;
function requireRenewalVerificationService() {
  if (!renewalVerificationService) {
    renewalVerificationService = RenewalVerificationService.create({
      getInventoryImage,
      createImageBitmapFn: globalThis.createImageBitmap,
      OffscreenCanvasCtor: globalThis.OffscreenCanvas
    });
  }
  return renewalVerificationService;
}

function normalizedComparableText(value) { return requireRenewalVerificationService().normalizedComparableText(value); }

function normalizedScalar(value) { return requireRenewalVerificationService().normalizedScalar(value); }

function dynamicAttributeMap(record) { return requireRenewalVerificationService().dynamicAttributeMap(record); }

async function imageVisualVector(imageKey) { return await requireRenewalVerificationService().imageVisualVector(imageKey); }

function meanAbsoluteVectorDifference(a, b) { return requireRenewalVerificationService().meanAbsoluteVectorDifference(a, b); }

function inventoryImageSetExplicitlyEmpty(record) { return requireRenewalVerificationService().inventoryImageSetExplicitlyEmpty(record); }

async function compareRenewalImages(source, candidate) { return await requireRenewalVerificationService().compareRenewalImages(source, candidate); }

async function compareRenewalRecords(source, candidate, options = {}) { return await requireRenewalVerificationService().compareRenewalRecords(source, candidate, options); }

function normalizedComparableBoolean(value) { return requireRenewalVerificationService().normalizedComparableBoolean(value); }



function renewalComparisonHasOnlyVisibilityUncertainty(comparison) { return requireRenewalVerificationService().renewalComparisonHasOnlyVisibilityUncertainty(comparison); }

function renewalComparisonWaitsOnlyForOnline(comparison) { return requireRenewalVerificationService().renewalComparisonWaitsOnlyForOnline(comparison); }

function renewalOutcomeForComparison(comparison) { return requireRenewalVerificationService().renewalOutcomeForComparison(comparison); }

function markStoredComparisonOnline(comparison) { return requireRenewalVerificationService().markStoredComparisonOnline(comparison); }





const automaticReplacementInFlight = new Set();






























const TEMPLATE_TARGET_URL = "https://www.kleinanzeigen.de/p-anzeige-aufgeben-schritt2.html";
const TEMPLATE_FILL_SESSIONS_KEY = "templateFillSessions";
const TEMPLATE_FILL_MAX_AGE_MS = 2 * 60 * 60 * 1000;

async function getInventory(inventoryId) { return requireInventoryRepository().get(inventoryId); }

async function getInventoryImage(imageKey) { return requireInventoryImageStore().get(imageKey); }

async function readFillSessions() { return requireTemplateFillService().readFillSessions(); }
async function writeFillSessions(sessions) { return requireTemplateFillService().writeFillSessions(sessions); }
const TERMINAL_TEMPLATE_FILL_STATUSES = new Set(['complete', 'needs-review', 'error']);
function withTemplateFillMutation(task) { return requireTemplateFillService().withTemplateFillMutation(task); }
async function terminalizeTemplateFillForWatchdog(fillId, issue) { return requireTemplateFillService().terminalizeTemplateFillForWatchdog(fillId, issue); }

function templatePayload(record) { return requireTemplateFillService().templatePayload(record); }
function assertTemplateSourceReady(record) { return requireTemplateFillService().assertTemplateSourceReady(record); }

function renewalHoldsInsertionLock(session) { return RenewalStateRepository.renewalHoldsInsertionLock(session); }
function isSafeLegacyManualEmergencyReset(session) { return RenewalStateRepository.isSafeLegacyManualEmergencyReset(session); }
function isSafePrePublishPaidInsertion(session) { return RenewalStateRepository.isSafePrePublishPaidInsertion(session); }
function emergencyResetRenewalState(session, options) { return RenewalStateRepository.emergencyResetRenewalState(session, options); }
function isCheckoutAbortedRecoveryCandidate(session, evidence) { return RenewalStateRepository.isCheckoutAbortedRecoveryCandidate(session, evidence); }
function evaluateCheckoutRecoveryProof(input) { return RenewalStateRepository.evaluateCheckoutRecoveryProof(input); }

function templateFillHoldsInsertionLock(session) { return requireTemplateFillService().templateFillHoldsInsertionLock(session); }

function insertionLockSortTime(item) { return requireInsertionLockService().insertionLockSortTime(item); }

async function getInsertionLockState() { return await requireInsertionLockService().getInsertionLockState(); }

function insertionLockMessage(lock) { return requireInsertionLockService().insertionLockMessage(lock); }

async function assertInsertionStartAvailable(request = {}) { return await requireInsertionLockService().assertInsertionStartAvailable(request); }

function publishedAdCandidateFromUrl(rawUrl, sourceAdId = '') {
  return requireListingUrlEvidenceService().publishedAdCandidateFromUrl(rawUrl, sourceAdId);
}

function recoverableTrashTemplateFill(session) { return requireTemplateFillController().recoverableTrashTemplateFill(session); }

async function getRecoverableTrashTemplateFill() { return await requireTemplateFillController().getRecoverableTrashTemplateFill(); }

let publishedInventoryResolver = null;
function requirePublishedInventoryResolver() {
  if (!publishedInventoryResolver) publishedInventoryResolver = PublishedInventoryResolver.create({
    getTab: tabId => chrome.tabs.get(tabId),
    updateTab: (tabId, properties) => updateAutomationTab(tabId, properties),
    waitForExpectedComplete: (tabId, expectedUrl, options) => waitForExpectedTabComplete(tabId, expectedUrl, options),
    ensureContentConnection,
    tabMessage: (tabId, message) => sendTabRequest(tabId, message),
    log: (event, details) => logDiagnostic('info', event, details, { module: 'published-inventory-resolver', operation: 'trash-template-inventory-capture', context: { adId: details?.adId || null, targetTabId: details?.tabId || null } }).catch(() => {})
  });
  return publishedInventoryResolver;
}

async function prepareTrashTemplateInventoryCapture(message = {}) { return await requireTemplateFillController().prepareTrashTemplateInventoryCapture(message); }

async function completeTrashTemplateFlow(message = {}) { return await requireTemplateFillController().completeTrashTemplateFlow(message); }

async function getTrashTemplateFillStatus(message = {}) { return await requireTemplateFillController().getTrashTemplateFillStatus(message); }

async function startTrashTemplateFillUnlocked(inventoryId) { return await requireTemplateFillController().startTrashTemplateFillUnlocked(inventoryId); }

async function startTemplateFillUnlocked(inventoryId, { autoReplacementAllowed = false, startConfirmationVersion = null, renewalModeOverride = null, maxPhaseAttemptsOverride = null, massBatchId = null, massBatchItemIndex = null, parentOperationId = null } = {}) { return await requireTemplateFillController().startTemplateFillUnlocked(inventoryId, { autoReplacementAllowed, startConfirmationVersion, renewalModeOverride, maxPhaseAttemptsOverride, massBatchId, massBatchItemIndex, parentOperationId }); }

async function startTrashTemplateFill(inventoryId) { return await requireTemplateFillController().startTrashTemplateFill(inventoryId, arguments[1] || {}); }

async function startTemplateFill(inventoryId, options = {}) { return await requireTemplateFillController().startTemplateFill(inventoryId, options); }

const renewalPhase1RetryInFlight = new Set();

let renewalPhase1RetryService = null;
function requireRenewalPhase1RetryService() {
  if (!renewalPhase1RetryService) renewalPhase1RetryService = RenewalPhase1RetryService.create({
    sessionPort: { readRenewalSessions, readFillSessions, writeFillSessions, persistRenewalSession },
    policyPort: { renewalPhaseAttemptAvailable, renewalAttemptState, beginRenewalPhaseAttempt, normalizeRenewalMode, renewalMaxPhaseAttempts },
    tabPort: { createAutomationTab, registerShadowTab, closeRegistryTab, updateAutomationTab },
    diagnosticsPort: { correlationContext, sessionCorrelationContext, logDiagnostic },
    configPort: { crypto, TEMPLATE_TARGET_URL, TAB_ROLES },
    statePort: { renewalPhase1RetryInFlight }
  });
  return renewalPhase1RetryService;
}
function canRetryRenewalPhase1(renewal, fill = null) {
  return requireRenewalPhase1RetryService().canRetryRenewalPhase1(renewal, fill);
}
async function restartRenewalPhase1Attempt(renewalId, failedFillId, reason = 'phase-1-fill-failed') {
  return requireRenewalPhase1RetryService().restartRenewalPhase1Attempt(renewalId, failedFillId, reason);
}

async function deleteImagesByInventoryId(inventoryId) { return requireInventoryImageStore().deleteByInventoryId(inventoryId); }





function archiveInsertionMeta(session) { return requireArchiveInsertionService().archiveInsertionMeta(session); }


















async function getTemplateFillSession(sender) { return requireTemplateFillService().getTemplateFillSession(sender); }

function evictTemplateImageTransfer(fillId, imageKey) { return requireTemplateFillService().evictTemplateImageTransfer(fillId, imageKey); }
function evictTemplateImageTransfersForFill(fillId) { return requireTemplateFillService().evictTemplateImageTransfersForFill(fillId); }
function evictTemplateImageTransfersForTab(tabId) { return requireTemplateFillService().evictTemplateImageTransfersForTab(tabId); }
async function resolveTemplateImageTransfer(message, sender) { return requireTemplateFillService().resolveTemplateImageTransfer(message, sender); }
async function templateImageChunk(message, sender) { return requireTemplateFillService().templateImageChunk(message, sender); }

function isTransientTemplateFillProgress(stage, status, result) { return requireTemplateFillService().isTransientTemplateFillProgress(stage, status, result); }
function templateFillProgressSnapshot(session, stage, updatedAt = new Date().toISOString()) { return requireTemplateFillService().templateFillProgressSnapshot(session, stage, updatedAt); }

async function updateTemplateFillSession(message, sender) { return await requireTemplateFillController().updateTemplateFillSession(message, sender); }

chrome.windows?.onRemoved?.addListener(windowId => {
  (async () => {
    const stored = await chrome.storage.session.get(APP_WINDOW_SESSION_KEY).catch(() => ({}));
    if (Number(stored?.[APP_WINDOW_SESSION_KEY] || 0) === Number(windowId)) {
      await chrome.storage.session.remove(APP_WINDOW_SESSION_KEY).catch(() => {});
    }
  })().catch(() => {});
});

async function terminalizeTemplateFillOnPlatformError(tabId, rawUrl, evidence = {}) { return await requireTemplateFillController().terminalizeTemplateFillOnPlatformError(tabId, rawUrl, evidence); }

const renewalPublishDetectionInFlight = new Set();
let tabLifecycleObserver = null;
function requireTabLifecycleObserver() {
  if (!tabLifecycleObserver) {
    tabLifecycleObserver = TabLifecycleObserver.create({
      tabRegistry,
      chromeTabs: chrome.tabs,
      roles: TAB_ROLES,
      goneState: TAB_STATES.GONE,
      isGoneError: error => TabRegistry.isGoneError(error),
      logDiagnostic,
      notifyTabLoadWaiters,
      evictTemplateImageTransfersForTab,
      readFillSessions,
      writeFillSessions,
      readRenewalSessions,
      persistRenewalSession,
      readArchiveInsertionSessions,
      persistArchiveInsertionSession,
      broadcastInventoryChanged,
      getBulkRunState,
      writeBulkRunState,
      mutateBulkRunState,
      closeRegistryTabs
    });
  }
  return tabLifecycleObserver;
}
function registryEntryIsOwnedWorker(entry) {
  if (!entry || entry.lifecycleState === TAB_STATES.GONE) return false;
  const owner = entry.owner && typeof entry.owner === 'object' ? entry.owner : {};
  const hasOwner = Boolean(owner.ownerId || owner.operationId || owner.renewalId || owner.archiveInsertionId || owner.bulkRunId || owner.runId || owner.fillId);
  return hasOwner && (entry.managed === true || entry.role === TAB_ROLES.BULK_WORKER || entry.role === TAB_ROLES.RENEWAL_WORKER || entry.role === TAB_ROLES.ARCHIVE_WORKER || entry.role === TAB_ROLES.WORKER);
}

async function observeTabLifecycleUpdate(tab) { return requireTabLifecycleObserver().observeTabLifecycleUpdate(tab); }

chrome.storage?.onChanged?.addListener((changes, areaName) => {
  if (areaName === 'local' && changes?.[PLATFORM_ACCESS_RESTRICTION_KEY]?.newValue) {
    notifyAllTabLoadWaiters({ kind: 'platform-restriction' });
  }
});

chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
  if (changeInfo?.status || changeInfo?.url) notifyTabLoadWaiters(tabId, { kind: 'updated', status: changeInfo.status || tab?.status || null, url: changeInfo.url || tab?.url || null, tab });
  if (tab?.id) void withAutonomousAdmission('tab-lifecycle-update', () => observeTabLifecycleUpdate(tab)).catch(() => {});
  const observedUrl = String(changeInfo.url || tab?.url || '');
  const platformError = classifyKleinanzeigenInsertionErrorUrl(observedUrl, { title: tab?.title || '' });
  if (platformError.isError) {
    void withAutonomousAdmission('template-error-terminalize', () => terminalizeTemplateFillOnPlatformError(tabId, observedUrl, { ...platformError, title: tab?.title || '', source: 'tab-navigation' })).catch(async error => {
      await logDiagnostic('error', 'KLEINANZEIGEN_ERROR_PAGE_TERMINALIZATION_FAILED', {
        tabId, path: platformError.path || null, errorCode: platformError.errorCode || null,
        message: String(error.message || error).slice(0, 800)
      }, { module: 'background', operation: 'template-fill', context: { targetTabId: tabId } }).catch(() => {});
    });
  }
  if (changeInfo.status !== 'complete' || renewalPublishDetectionInFlight.has(tabId)) return;
  renewalPublishDetectionInFlight.add(tabId);
  void withAutonomousAdmission('renewal-publish-detection', async () => {
    const fills = await readFillSessions();
    const fill = Object.values(fills).find(item => item?.targetTabId === tabId && (item?.renewalId || item?.archiveInsertionId) && item?.stage === 'publish-submitted' && item?.status === 'running');
    if (!fill) return;
    try {
      const detected = await detectPublishedAdForFill(tabId, fill.sourceAdId);
      if (!detected?.adId) {
        const currentTab = await chrome.tabs.get(tabId).catch(() => null);
        let path = '';
        try { path = new URL(String(currentTab?.url || '')).pathname; } catch { /* ignore */ }
        if (fill.renewalId && path === '/m-bestellung-aufnehmen.html') {
          const renewals = await readRenewalSessions().catch(() => ({}));
          const renewal = renewals[fill.renewalId];
          if (renewal && !renewal.newAdId) {
            renewal.checkoutObservedAt = renewal.checkoutObservedAt || new Date().toISOString();
            renewal.checkoutPath = path;
            renewal.paidInsertion = { ...(renewal.paidInsertion || {}), phase: 'checkout', source: renewal.paidInsertion?.source || 'post-publish-navigation' };
            await persistRenewalSession(renewal).catch(() => {});
          }
        }
        await logDiagnostic('info', fill.archiveInsertionId ? 'ARCHIVE_INSERT_NEW_ID_DETECTION_PENDING' : 'RENEWAL_NEW_ID_DETECTION_PENDING', {
          fillId: fill.fillId, renewalId: fill.renewalId || null, archiveInsertionId: fill.archiveInsertionId || null,
          reason: 'no-candidate', path: path || null
        }, { module: 'background', operation: fill.archiveInsertionId ? 'archive-import-publish-detect' : 'renewal-publish-detect', context: sessionCorrelationContext(fill, { renewalId: fill.renewalId || null, adId: fill.sourceAdId, targetTabId: tabId }) }).catch(() => {});
        return;
      }
      if (fill.archiveInsertionId) await confirmPublishedArchiveInsertion(fill, detected);
      else await confirmPublishedRenewal(fill, detected);
    } catch (error) {
      await logDiagnostic('warning', fill.archiveInsertionId ? 'ARCHIVE_INSERT_NEW_ID_DETECTION_PENDING' : 'RENEWAL_NEW_ID_DETECTION_PENDING', {
        fillId: fill.fillId, renewalId: fill.renewalId || null, archiveInsertionId: fill.archiveInsertionId || null,
        message: String(error.message || error).slice(0, 500)
      }, { module: 'background', operation: fill.archiveInsertionId ? 'archive-import-publish-detect' : 'renewal-publish-detect', context: sessionCorrelationContext(fill, { renewalId: fill.renewalId || null, adId: fill.sourceAdId, targetTabId: tabId }) }).catch(() => {});
    }
  }).catch(error => {
    void logDiagnostic('warning', 'RENEWAL_PUBLISH_AUTO_ADMISSION_REJECTED', {
      errorCode: String(error?.code || ''), tabId
    }, { module: 'background', operation: 'renewal-publish-auto-admission' }).catch(() => {});
  }).finally(() => renewalPublishDetectionInFlight.delete(tabId));
});

chrome.tabs?.onActivated?.addListener(({ tabId }) => {
  void withAutonomousAdmission('tab-activated', () => requireTabLifecycleObserver().handleActivated(tabId)).catch(() => {});
});

chrome.tabs?.onRemoved?.addListener(tabId => {
  void withAutonomousAdmission('tab-removed', () => requireTabLifecycleObserver().handleRemoved(tabId)).catch(() => {});
});


let workflowEmergencyResetController = null;
function requireWorkflowEmergencyResetController() {
  if (!workflowEmergencyResetController) {
    workflowEmergencyResetController = WorkflowEmergencyResetController.create({
      bumpEmergencyResetGeneration, resetMassRenewalWorkflowRuntimeState,
      automaticReplacementInFlight, renewalPhase1RetryInFlight, renewalPublishDetectionInFlight, trashTemplatePublishDetectionInFlight,
      mutateBulkRunState, closeRegistryTabs, closeRegistryTab, releaseBulkSourceOwnership,
      readFillSessions, writeFillSessions, requireTemplateFillService,
      RenewalStateRepository, readRenewalSessions, writeRenewalSessions, renewalHoldsInsertionLock,
      isSafeLegacyManualEmergencyReset, isSafePrePublishPaidInsertion, emergencyResetRenewalState,
      readArchiveInsertionSessions, writeArchiveInsertionSessions, readMassRenewalBatch, writeMassRenewalBatch,
      touchMassRenewalItemProgress, getTabRegistrySnapshot, TAB_STATES,
      logDiagnostic, sessionCorrelationContext, broadcastInventoryChanged
    });
  }
  return workflowEmergencyResetController;
}
async function resetActiveWorkflows() { return requireWorkflowEmergencyResetController().resetActiveWorkflows(); }

function isNormalTabGoneLifecycleError(error, message) {
  const text = String(error?.message || error || '');
  const expectedClosed = error?.code === 'KR_TAB_EXPECTED_CLOSED' || /KR_TAB_EXPECTED_CLOSED/i.test(text);
  return expectedClosed && String(message?.type || '') === 'ENSURE_CONTENT_CONNECTION';
}

function isExpectedPostRecoveryBulkClose(error, message, run) {
  if (message?.type !== 'BULK_CLOSE_WORKER') return false;
  const text = String(error?.message || error || '');
  const noActiveRun = !run || String(run.status || '') !== 'running';
  return noActiveRun && /Keine aktive Erfassung vorhanden|Erfassung wurde nicht gefunden|nicht mehr aktiv/i.test(text);
}

let nativeStatusBridge = null;
function requireNativeStatusBridge() {
  // Instantiate on the first trusted app request: legacy VM fixtures deliberately
  // load the background script without Chrome Native Messaging/these dependencies.
  if (nativeStatusBridge) return nativeStatusBridge;
  const nativeUpdateGateway = NativeUpdateStatusGateway.create({
  getPlatform: () => new Promise(resolve => {
    chrome.runtime.getPlatformInfo(info => {
      resolve(!chrome.runtime.lastError && info?.os === 'win' ? 'win' : 'unsupported');
    });
  }),
  newNonce: () => Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join(''),
  transport: (host, payload) => new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(host, payload, response => {
      if (chrome.runtime.lastError) reject(new Error(String(chrome.runtime.lastError.message || 'HOST_UNAVAILABLE')));
      else resolve(response);
    });
  }),
  timeoutMs: 5000
  });
  nativeStatusBridge = NativeStatusBridge.create({
  gateway: nativeUpdateGateway,
  getExtensionId: () => chrome.runtime.id,
  getAppUrl: () => chrome.runtime.getURL(APP_PAGE),
  getAppWindowId: async () => {
    const value = await chrome.storage.session.get(APP_WINDOW_SESSION_KEY);
    return value?.[APP_WINDOW_SESSION_KEY];
  },
  getWindow: windowId => chrome.windows.get(windowId),
  getTab: tabId => chrome.tabs.get(tabId)
  });
  
  return nativeStatusBridge;
}

// No trusted 15-owner snapshot provider exists yet: reserve always fails closed.
let atomicMV3Admission = null;
function requireAtomicMV3Admission() {
  if(!atomicMV3Admission) {
    if(typeof AtomicMV3Admission?.create!=='function')
      throw new Error('KR_UPDATE_FENCE_ATOMIC_UNAVAILABLE');
    atomicMV3Admission=AtomicMV3Admission.create({
      storageLocal:chrome.storage.local,lockManager:globalThis.navigator?.locks,
      workerInstanceId:ownerWorkerInstanceId,clock:()=>Date.now(),
      newToken:()=>crypto.randomUUID()
    });
  }
  return atomicMV3Admission;
}
let updateWorkflowFence = null;
function requireUpdateWorkflowFence() {
  if (!updateWorkflowFence) {
    if (typeof UpdateWorkflowFence?.create !== 'function')
      throw new Error('KR_UPDATE_FENCE_UNAVAILABLE');
    updateWorkflowFence = UpdateWorkflowFence.create({
      storageLocal: chrome.storage.local,
      clock: () => Date.now(),
      newToken: () => crypto.randomUUID(),
      atomicCoordinator: requireAtomicMV3Admission()
    });
  }
  return updateWorkflowFence;
}
// This tracker covers positively identified autonomous paths only. Message
// handlers, detached tasks and previous worker generations still need their
// own complete proofs before KAR-97 can treat ANY owner as confirmed idle.
const ownerWorkerInstanceId = crypto.randomUUID();
let persistedOwnerObserver = null;
function requirePersistedOwnerObserver() {
  if (!persistedOwnerObserver) {
    if (typeof PersistedOwnerObserver?.create !== 'function') throw new Error('KR_UPDATE_OWNER_OBSERVER_UNAVAILABLE');
    persistedOwnerObserver = PersistedOwnerObserver.create({
      storageLocal: chrome.storage.local, storageSession: chrome.storage.session, clock: () => Date.now(),
      workerInstanceId:ownerWorkerInstanceId
    });
  }
  return persistedOwnerObserver;
}
// The private gate uses the existing, read-only authenticated Kleinanzeigen
// account/profile match from KRAdditionalOwnerObserver (without an extra
// seller userId or email syntax check). It remains FAIL-CLOSED for updater
// reserve: 15 crash-durable owner-completion producers and independent
// NativeHost transaction recovery are still absent. A matched account
// is never equivalent to all-15 owner IDLE.
// Do not add an app/content route to captureForReserve/reserveThroughFence.
const privateOwnerUpdateAuthority = typeof TrustedOwnerAuthority?.create === 'function'
  && typeof UpdateIdlePolicy?.evaluate === 'function'
  ? TrustedOwnerAuthority.create({
  storageLocal: chrome.storage.local, storageSession: chrome.storage.session,
  clock: () => Date.now(), newToken: () => crypto.randomUUID(),
  workerInstanceId: ownerWorkerInstanceId,
  ownerPolicy: UpdateIdlePolicy, lockManager: globalThis.navigator?.locks,
  // This function is invoked only inside a later private capture under the
  // existing Web Lock. The observer independently rechecks PAGE_STATUS.
  readLiveAccountReadOnly: () => requireAdditionalOwnerObserver().observe(),
  readBrowserTabsReadOnly: () => requireAdditionalOwnerObserver().readVerifiedUnmanagedTabsReadOnly()
}) : null;
// In older VM fixture harnesses this module is intentionally absent; that
// keeps only the optional *positive* updater authority disabled. Ordinary
// routed safety remains enforced by the existing P8 admission gate.
void privateOwnerUpdateAuthority;
// Additional owner observation is ACTIVE/UNKNOWN only and cannot grant a lease.
let additionalOwnerObserver = null;
function requireAdditionalOwnerObserver() {
  if (!additionalOwnerObserver) {
    if (typeof AdditionalOwnerObserver?.create !== 'function')
      throw new Error('KR_ADDITIONAL_OWNER_OBSERVER_UNAVAILABLE');
    additionalOwnerObserver = AdditionalOwnerObserver.create({
      storageLocal:chrome.storage.local,storageSession:chrome.storage.session,
      clock:()=>Date.now(),workerInstanceId:ownerWorkerInstanceId,
      queryBrowserTabsReadOnly:()=>chrome.tabs.query({}),
      readAccountPageStatusReadOnly:tabId=>sendTabRequest(tabId,{type:'PAGE_STATUS'})
    });
  }
  return additionalOwnerObserver;
}
const AUTONOMOUS_PERSISTED_OWNER_KINDS = Object.freeze({
  'bulk-runtime-recovery': ['bulkInventory', 'bulkReconciliation'],
  'bulk-watchdog': ['bulkInventory'],
  'renewal-resume': ['renewal', 'insertionLock'],
  'renewal-detached-verify': ['renewal', 'insertionLock'],
  'renewal-detached-retry': ['renewal', 'insertionLock'],
  'renewal-auto-phase4': ['renewal', 'insertionLock'],
  'renewal-publish-detection': ['renewal', 'templateFill', 'archiveInsertion', 'insertionLock'],
  'mass-resume': ['massRenewal', 'insertionLock'],
  'mass-renewal-next-item': ['massRenewal', 'insertionLock'],
  'mass-renewal-watchdog-timer': ['massRenewal', 'insertionLock'],
  'renewal-phase1-retry': ['renewal', 'templateFill', 'insertionLock'],
  'archive-resume': ['archiveInsertion', 'templateFill', 'insertionLock'],
  'archive-postpublish-detached': ['archiveInsertion', 'templateFill', 'insertionLock'],
  'template-error-terminalize': ['renewal', 'templateFill', 'archiveInsertion', 'insertionLock'],
  // Tab-driven paths can update several persisted sessions or reload a managed
  // worker; conservatively hold every candidate owner until the handler settles.
  'trash-publish-detection': ['templateFill', 'insertionLock'],
  'tab-removed': ['bulkInventory', 'bulkReconciliation', 'renewal', 'templateFill', 'archiveInsertion', 'insertionLock'],
  'tab-lifecycle-update': ['bulkInventory', 'bulkReconciliation', 'renewal', 'massRenewal', 'templateFill', 'archiveInsertion', 'insertionLock']
});
// Routed/autonomous callbacks share P8 fence and owner trackers; missing sources fail closed.
function withAutonomousAdmission(kind, task) {
  try {
    const names = AUTONOMOUS_PERSISTED_OWNER_KINDS[kind];
    if (names) {
      const admittedTask = task;
      task = admissionReceipt => requirePersistedOwnerObserver().track(names, () => admittedTask(admissionReceipt));
    }
    const started = task;
    const namesForKind = AdditionalOwnerObserver.ownersForOperation(kind, 'autonomous');
    task = admissionReceipt => requireAdditionalOwnerObserver().track(namesForKind, () => started(admissionReceipt));
    return requireUpdateWorkflowFence().withAdmission('AUTONOMOUS:' + kind, task);
  } catch (error) { return Promise.reject(error); }
}
// All currently fenced routed handlers can transitively mutate any persisted
// workflow; conservatively count all seven for the lifetime of their admitted
// Promise. The same existing fence arbitrates admission. This is in-memory
// BUSY evidence only, never proof of idle after restart or update permission.
function withRoutedAdmission(type, task) {
  const namesForType = AdditionalOwnerObserver.ownersForOperation(type, 'routed');
  return requireUpdateWorkflowFence().withAdmission(type, admissionReceipt => requirePersistedOwnerObserver().track(PersistedOwnerObserver.OWNERS, () => namesForType.length ? requireAdditionalOwnerObserver().track(namesForType, () => task(admissionReceipt)) : task(admissionReceipt)));
}
const backgroundMessageRouter = BackgroundMessageRouter.create({
  withWorkflowAdmission: (type, task) => withRoutedAdmission(type, task),
  MessageContractRegistry,
  assertPlatformAccessAllowedForRequest,
  handlers: Object.freeze({
  "PLATFORM_ACCESS_RESTRICTED": (message, sender) => activatePlatformAccessRestriction(message, sender),
  "GET_PLATFORM_ACCESS_RESTRICTION": (message, sender) => readPlatformAccessRestriction(),
  "CLEAR_PLATFORM_ACCESS_RESTRICTION": (message, sender) => clearPlatformAccessRestriction(),
  "OPEN_APP_WINDOW": (message, sender) => openOrFocusAppWindow(),
  "GET_BACKGROUND_EPOCH": (message, sender) => ({ epoch: currentDiagnosticSessionId() }),
  "GET_NATIVE_UPDATE_STATUS": (message, sender) => requireNativeStatusBridge().status(message, sender),
  "LOG_DIAGNOSTIC_EVENT": (message, sender) => logClientDiagnostic(message, sender),
  "SET_ACCOUNT_GATE_DIAGNOSTIC_STATE": (message, sender) => setAccountGateDiagnosticState(message),
  "STORE_GALLERY_DIAGNOSTIC": (message, sender) => storeGalleryDiagnostic(message, sender),
  "GET_DIAGNOSTIC_OCCUPANCY": (message, sender) => readDiagnosticOccupancy(),
  "GET_DIAGNOSTIC_EXPORT": (message, sender) => requireDiagnosticExportService().buildDiagnosticExport(),
  "RESET_DIAGNOSTICS": (message, sender) => resetDiagnostics(),
  "RESET_ACTIVE_WORKFLOWS": (message, sender) => resetActiveWorkflows(),
  "ENSURE_CONTENT_CONNECTION": (message, sender) => ensureContentConnection(message),
  "GET_MANAGED_WORKER_TAB_IDS": (message, sender) => getManagedWorkerTabIds(),
  "GET_TAB_REGISTRY_SNAPSHOT": (message, sender) => getTabRegistrySnapshot(),
  "REACTIVATE_DISCARDED_TABS": (message, sender) => reactivateDiscardedTabs(message),
  "GET_RENEWAL_CONFIGURATION": (message, sender) => getRenewalConfiguration(),
  "GET_TRASH_RETENTION_CONFIGURATION": (message, sender) => getTrashRetentionConfiguration(),
  "PREVIEW_TRASH_RETENTION_CHANGE": (message, sender) => previewTrashRetentionChange(message),
  "COMMIT_TRASH_RETENTION_CHANGE": (message, sender) => commitTrashRetentionChange(message),
  "SET_RENEWAL_MODE": (message, sender) => setRenewalMode(message),
  "SET_RENEWAL_PHASE_ATTEMPTS": (message, sender) => setRenewalPhaseAttempts(message),
  "OPEN_EDIT_AD": (message, sender) => openEditAd(message),
  "OPEN_READONLY_AD": (message, sender) => openReadOnlyAd(message),
  "RECOGNIZE_PROFILE": (message, sender) => recognizeProfile(message),
  "GET_PROFILE_STATE": (message, sender) => getProfileState(),
  "PROBE_LIVE_KLEINANZEIGEN_ACCOUNT": (message, sender) => probeLiveKleinanzeigenAccount(),
  "SET_SELECTED_PROFILE": (message, sender) => setSelectedProfile(message),
  "PREPARE_PROFILE_BACKUP_IMPORT": (message, sender) => prepareProfileBackupImport(message),
  "FINALIZE_PROFILE_BACKUP_IMPORT": (message, sender) => finalizeProfileBackupImport(message),
  "DELETE_PROFILE": (message, sender) => deleteProfile(message),
  "ASSIGN_UNPROFILED_INVENTORIES": (message, sender) => assignUnprofiledInventories(message),
  "REFRESH_INVENTORY": (message, sender) => refreshInventoryRecord(message),
  "CHECK_INVENTORY_ONLINE_STATUS": (message, sender) => checkInventoryOnlineStatus(message),
  "CAPTURE_SINGLE_INVENTORY": (message, sender) => captureSingleInventory(message),
  "RETRY_RENEWAL_VERIFICATION": (message, sender) => retryRenewalVerification(message),
  "SAVE_INVENTORY": (message, sender) => saveInventory(message.payload),
  "LIST_INVENTORIES": (message, sender) => listInventories(Object.prototype.hasOwnProperty.call(message, 'profileId') ? message.profileId : undefined),
  "LIST_TRASH": (message, sender) => listTrashEntries(Object.prototype.hasOwnProperty.call(message, 'profileId') ? message.profileId : undefined),
  "GET_INSERTION_LOCK_STATE": (message, sender) => getInsertionLockState(),
  "DELETE_INVENTORY": (message, sender) => deleteInventory(message.inventoryId),
  "DELETE_TRASH_ENTRY": (message, sender) => deleteTrashEntry(message.inventoryId),
  "RESET_TRASH_RETENTION": (message, sender) => resetTrashRetention(message.inventoryId),
  "REMOVE_REPLACEMENT_READY_LOCAL": (message, sender) => removeReplacementReadyLocal(message),
  "FINISH_RENEWAL_REPLACEMENT": (message, sender, admissionReceipt) => finishRenewalReplacement(message, admissionReceipt),
  "DISCARD_RENEWAL_DRAFT": (message, sender) => discardRenewalDraft(message),
  "CLEAR_INVENTORIES": (message, sender) => clearInventories(Object.prototype.hasOwnProperty.call(message, 'profileId') ? message.profileId : undefined),
  "START_BULK_INVENTORY_OPERATION": (message, sender) => startBulkInventoryOperation(message),
  "BULK_INIT_RUN": (message, sender) => initBulkRun(message, sender),
  "GET_BULK_RUN_FOR_SOURCE": (message, sender) => bulkRunForSource(sender),
  "GET_BULK_RUN_STATUS": (message, sender) => getBulkRunState(),
  "BULK_RUN_UPDATE": (message, sender) => updateBulkRun(message, sender),
  "BULK_RECORD_ROSTER_PAGE": (message, sender) => recordBulkRosterPage(message, sender, { reconciliation: false }),
  "REQUEST_BULK_INVENTORY_STOP_AFTER_CURRENT": (message, sender) => requestBulkInventoryStopAfterCurrent(message),
  "BULK_FINISH_CONTROLLED_STOP": (message, sender) => finishBulkRunControlledStop(message, sender),
  "BULK_BEGIN_RECONCILIATION": (message, sender) => beginBulkReconciliation(message, sender),
  "BULK_RECORD_RECONCILIATION_PAGE": (message, sender) => recordBulkRosterPage(message, sender, { reconciliation: true }),
  "BULK_FINISH_RECONCILIATION": (message, sender) => finishBulkReconciliation(message, sender),
  "BULK_OPEN_WORKER": (message, sender) => openBulkWorker(message, sender),
  "BULK_EXTRACT_SAVE_WORKER": (message, sender) => extractSaveBulkWorker(message, sender),
  "BULK_CLOSE_WORKER": (message, sender) => closeBulkWorker(message, sender),
  "BULK_RECORD_EXISTING_SKIP": (message, sender) => recordBulkExistingSkip(message, sender),
  "BULK_RECORD_RESULT": (message, sender) => recordBulkResult(message, sender),
  "BULK_FINISH_RUN": (message, sender) => finishBulkRun(message, sender),
  "BULK_FAIL_RUN": (message, sender) => failBulkRun(message, sender),
  "RETRY_BULK_FAILURE": (message, sender) => retryBulkFailure(message),
  "START_MASS_RENEWAL_BATCH": (message, sender) => startMassRenewalBatch(message),
  "GET_MASS_RENEWAL_BATCH_STATUS": (message, sender) => getMassRenewalBatchStatus(),
  "MASS_RENEWAL_WATCHDOG_TICK": (message, sender) => massRenewalWatchdogTick(message, sender),
  "REQUEST_MASS_RENEWAL_STOP_AFTER_CURRENT": (message, sender) => requestMassRenewalStopAfterCurrent(message),
  "RETRY_MASS_RENEWAL_ITEM": (message, sender) => retryMassRenewalItem(message),
  "START_TEMPLATE_FILL": (message, sender) => startTemplateFill(message.inventoryId, { autoReplacementAllowed: message.autoReplacementAllowed === true, startConfirmationVersion: message.startConfirmationVersion }),
  "START_ARCHIVE_INSERTION": (message, sender) => startArchiveInsertion(message),
  "GET_ARCHIVE_INSERTION_STATUS": (message, sender) => getArchiveInsertionStatus(message),
  "START_TRASH_TEMPLATE_FILL": (message, sender) => {
    if (message?.schemaTestScenario != null) throw new Error('Manueller Schema-Prüfmodus wurde entfernt.');
    return startTrashTemplateFill(message.inventoryId, { supersedeFillId: message.supersedeFillId || null });
  },
  "GET_TRASH_TEMPLATE_FILL_STATUS": (message, sender) => getTrashTemplateFillStatus(message),
  "GET_RECOVERABLE_TRASH_TEMPLATE_FILL": (message, sender) => getRecoverableTrashTemplateFill(),
  "PREPARE_TRASH_TEMPLATE_INVENTORY_CAPTURE": (message, sender) => prepareTrashTemplateInventoryCapture(message),
  "COMPLETE_TRASH_TEMPLATE_FLOW": (message, sender) => completeTrashTemplateFlow(message),
  "GET_APP_NOTICE": (message, sender) => getAppNotice(),
  "DISMISS_APP_NOTICE": (message, sender) => dismissAppNotice(message),
  "RENEWAL_PUBLISH_CLICKED": (message, sender) => markRenewalPublishClicked(message, sender),
  "AUTHORIZE_AUTOMATIC_PUBLISH": (message, sender, admissionReceipt) => authorizeAutomaticPublish(message, sender, admissionReceipt),
  "GET_TEMPLATE_FILL_SESSION": (message, sender) => getTemplateFillSession(sender),
  "GET_TEMPLATE_IMAGE_CHUNK": (message, sender) => templateImageChunk(message, sender),
  "UPDATE_TEMPLATE_FILL_SESSION": (message, sender) => updateTemplateFillSession(message, sender),
  "GET_DIAGNOSTICS": (message, sender) => readDiagnostics(),
  })
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const messageContract = MessageContractRegistry.route(message?.type, 'background');
  backgroundMessageRouter.dispatch(message, sender, { messageContract }).then(
    result => sendResponse({ ok: true, result }),
    async error => {
      const run = await getBulkRunState().catch(() => null);
      const lifecycleGone = isNormalTabGoneLifecycleError(error, message);
      const expectedPostRecoveryBulkClose = isExpectedPostRecoveryBulkClose(error, message, run);
      const requestCorrelation = await resolveClientDiagnosticCorrelation(message, sender).catch(() => ({}));
      const contractRejected = ['KR_MESSAGE_CONTRACT_UNKNOWN', 'KR_MESSAGE_CONTRACT_TARGET_MISMATCH'].includes(String(error?.code || ''));
      const requestEvent = contractRejected
        ? 'MESSAGE_CONTRACT_REJECTED'
        : (lifecycleGone
          ? 'BACKGROUND_REQUEST_EXPECTED_TAB_CLOSED'
          : (expectedPostRecoveryBulkClose ? 'BACKGROUND_REQUEST_EXPECTED_BULK_CLOSE' : (TabRegistry.isGoneError(error) ? 'BACKGROUND_REQUEST_TAB_GONE' : 'BACKGROUND_REQUEST_FAILED')));
      await logDiagnostic(contractRejected ? 'warning' : (expectedPostRecoveryBulkClose ? 'info' : (lifecycleGone ? 'info' : 'error')), requestEvent, {
        message: String(error.message || error).slice(0, 600),
        ...((lifecycleGone || expectedPostRecoveryBulkClose) ? {} : { stack: String(error.stack || '').slice(0, 3000) }),
        requestType: message?.type || null,
        messageContract: { registered: messageContract.registered, targetRegistered: messageContract.targetRegistered, targets: messageContract.targets },
        stage: run?.stage || null
      }, {
        module: 'background',
        operation: message?.type || 'runtime-request',
        context: {
          ...requestCorrelation,
          adId: run?.currentAdId || message?.adId || null,
          workerTabId: requestCorrelation.workerTabId || run?.workerTabId || null,
          senderTabId: sender?.tab?.id ?? null
        }
      }).catch(() => {});
      sendResponse({ ok: false, error: error.message, errorCode: error?.code || null, errorDetails: error?.details && typeof error.details === 'object' ? error.details : null });
    }
  );
  return true;
});

chrome.tabs?.onUpdated?.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo?.url && changeInfo?.status !== 'complete') return;
  void withAutonomousAdmission('trash-publish-detection', () => maybeDetectTrashTemplatePublishedAd(tabId, changeInfo, tab)).catch(error => {
    void logDiagnostic('warning', 'TRASH_TEMPLATE_PUBLISH_DETECTION_FAILED', {
      tabId: Number(tabId || 0) || null,
      message: String(error?.message || error || '').slice(0, 500)
    }, { module: 'background', operation: 'trash-template-publish-detection', context: { targetTabId: Number(tabId || 0) || null } }).catch(() => {});
  });
});

chrome.action?.onClicked?.addListener(() => {
  void openOrFocusAppWindow().catch(error => {
    void logDiagnostic('error', 'APP_WINDOW_OPEN_FAILED', { message: String(error?.message || error).slice(0, 600) }, { module: 'background', operation: 'app-window' }).catch(() => {});
  });
});

// Startup maintenance mutates local registry/trash state outside the message router.
// Deny it while the persisted update lease is held, including after an MV3 restart.
// These short tasks use the same admission service as routed workflow requests.
void withAutonomousAdmission('tab-registry-boot', () => reconcileTabRegistry()).catch(() => {});
chrome.runtime.onStartup?.addListener(() => { void withAutonomousAdmission('tab-registry-startup', () => reconcileTabRegistry()).catch(() => {}); });

// Configurable local-trash expiry is mutating maintenance, not just a read.
// All three autonomous launch paths must observe the persistent update fence.
void withAutonomousAdmission('trash-purge-boot', () => purgeExpiredTrash()).catch(() => {});
chrome.runtime.onStartup?.addListener(() => { void withAutonomousAdmission('trash-purge-startup', () => purgeExpiredTrash()).catch(() => {}); });
chrome.runtime.onInstalled?.addListener(() => { void withAutonomousAdmission('trash-purge-installed', () => purgeExpiredTrash()).catch(() => {}); });

// Bulk inventory recovery: extension reload/browser restart invalidates the session lease,
// while an independent watchdog enforces the hard per-item deadline even if the source loop stalls.
void withAutonomousAdmission('bulk-runtime-recovery', () => ensureBulkRuntimeRecovery()).catch(() => {});
void withAutonomousAdmission('bulk-watchdog', () => bulkRunWatchdogTick()).catch(() => {});
if (typeof setInterval === 'function') setInterval(() => { void withAutonomousAdmission('bulk-watchdog', () => bulkRunWatchdogTick()).catch(() => {}); }, BULK_RUN_WATCHDOG_TICK_MS);

// Recover persisted workflows only when no platform safety stop is active.
void readPlatformAccessRestriction().then(state => {
  if (state?.active) return;
  void withAutonomousAdmission('renewal-resume', () => resumePendingRenewals()).finally(() => withAutonomousAdmission('mass-resume', () => resumeMassRenewalBatch()).catch(() => {})).catch(() => {});
  void withAutonomousAdmission('archive-resume', () => resumePendingArchiveInsertions()).catch(() => {});
}).catch(() => {});
